
# Mental Health Care System Backend

A Node.js + Express backend with JWT authentication, MongoDB persistence, and APIs for surveys, avatars, community posts, and user management.

## Setup Instructions
1. Run `npm install`
2. Create a `.env` file with your MongoDB URI and JWT secret.
3. Run `npm start` to launch the backend server.
