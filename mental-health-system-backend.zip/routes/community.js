
const express = require('express');
const { postCommunity, getCommunityPosts } = require('../controllers/communityController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', authMiddleware, postCommunity);
router.get('/', getCommunityPosts);

module.exports = router;
