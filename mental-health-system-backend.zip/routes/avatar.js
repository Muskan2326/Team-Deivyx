
const express = require('express');
const { saveAvatar, getAvatar } = require('../controllers/avatarController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', authMiddleware, saveAvatar);
router.get('/', authMiddleware, getAvatar);

module.exports = router;
