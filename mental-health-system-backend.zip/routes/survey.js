
const express = require('express');
const { submitSurvey, getSurveys } = require('../controllers/surveyController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/', authMiddleware, submitSurvey);
router.get('/', authMiddleware, getSurveys);

module.exports = router;
