
const mongoose = require('mongoose');

const SurveySchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  mealFrequency: String,
  dietType: String,
  skippedMeals: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Survey', SurveySchema);
