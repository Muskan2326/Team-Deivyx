
const mongoose = require('mongoose');

const AvatarSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  hairStyle: String,
  hairColor: String,
  imageUrl: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Avatar', AvatarSchema);
