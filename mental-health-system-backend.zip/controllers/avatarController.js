
const Avatar = require('../models/Avatar');

exports.saveAvatar = async (req, res) => {
  const avatar = new Avatar({ ...req.body, userId: req.user.id });
  await avatar.save();
  res.status(201).json({ message: 'Avatar saved successfully' });
};

exports.getAvatar = async (req, res) => {
  const avatar = await Avatar.findOne({ userId: req.user.id });
  res.json(avatar);
};
