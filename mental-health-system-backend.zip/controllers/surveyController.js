
const Survey = require('../models/Survey');

exports.submitSurvey = async (req, res) => {
  const survey = new Survey({ ...req.body, userId: req.user.id });
  await survey.save();
  res.status(201).json({ message: 'Survey submitted successfully' });
};

exports.getSurveys = async (req, res) => {
  const surveys = await Survey.find({ userId: req.user.id });
  res.json(surveys);
};
