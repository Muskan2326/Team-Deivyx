
const CommunityPost = require('../models/CommunityPost');

exports.postCommunity = async (req, res) => {
  const post = new CommunityPost({ ...req.body, userId: req.user.id });
  await post.save();
  res.status(201).json({ message: 'Post published successfully' });
};

exports.getCommunityPosts = async (req, res) => {
  const posts = await CommunityPost.find().sort({ createdAt: -1 });
  res.json(posts);
};
