# Mental Health Care System Frontend

This is a lovable, soothing React frontend designed to support mental health through interactive features.