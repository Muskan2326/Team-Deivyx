// Placeholder Dashboard Component
function Dashboard() { return <div>Dashboard</div>; }
export default Dashboard;