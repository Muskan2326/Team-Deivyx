// Placeholder Chatbot Component
function Chatbot() { return <div>Chatbot Interface</div>; }
export default Chatbot;