
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 bg-white bg-opacity-80 p-4 flex justify-between items-center shadow">
      <div className="text-xl font-bold">MentalHealthCare</div>
      <div className="space-x-4">
        <Link to="/profile">Profile</Link>
        <Link to="/">Home</Link>
        <Link to="/help">Help</Link>
        <Link to="/community">Community</Link>
        <Link to="/survey">Survey</Link>
        <Link to="/dashboard">Dashboard</Link>
      </div>
    </nav>
  );
}

export default Navbar;
