
function Footer() {
  return (
    <footer className="fixed bottom-0 left-0 right-0 bg-white bg-opacity-80 p-4 text-center text-sm">
      © 2025 MentalHealthCare. All rights reserved.
    </footer>
  );
}

export default Footer;
