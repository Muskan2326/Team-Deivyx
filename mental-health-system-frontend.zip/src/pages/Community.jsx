// Placeholder Community Page
function Community() { return <div>Community Page</div>; }
export default Community;