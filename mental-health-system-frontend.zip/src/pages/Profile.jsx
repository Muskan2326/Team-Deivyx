// Placeholder Profile Page
function Profile() { return <div>Profile Page</div>; }
export default Profile;