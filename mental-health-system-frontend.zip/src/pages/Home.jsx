
function Home() {
  return (
    <div className="text-center mt-20 text-white">
      <h1 className="text-4xl font-bold">Welcome to MentalHealthCare</h1>
      <p className="mt-4">Your companion for mental wellness, peer support, and self-expression.</p>
    </div>
  );
}

export default Home;
