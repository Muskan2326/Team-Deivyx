
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Howl } from 'howler';
import backgroundVideo from './assets/background.mp4';
import alphaBeat from './assets/alpha-beat.mp3';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Profile from './pages/Profile';
import Help from './pages/Help';
import Community from './pages/Community';
import Survey from './pages/Survey';
import Dashboard from './pages/Dashboard';

function App() {
  const sound = new Howl({ src: [alphaBeat], loop: true, volume: 0.3 });

  React.useEffect(() => { sound.play(); return () => sound.stop(); }, []);

  return (
    <Router>
      <div className="relative min-h-screen text-gray-800">
        <video autoPlay loop muted className="fixed inset-0 w-full h-full object-cover">
          <source src={backgroundVideo} type="video/mp4" />
        </video>
        <Navbar />
        <div className="relative z-10 p-4">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/help" element={<Help />} />
            <Route path="/community" element={<Community />} />
            <Route path="/survey" element={<Survey />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Routes>
        </div>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
