"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, User, Heart, MessageCircle, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"

type MoodType = "positive" | "neutral" | "support"

export function CreatePost() {
  const [content, setContent] = useState("")
  const [selectedMood, setSelectedMood] = useState<MoodType>("neutral")
  const [isPosting, setIsPosting] = useState(false)

  const moods = [
    {
      type: "positive" as MoodType,
      label: "Celebrating",
      icon: Sparkles,
      color: "bg-green-100 text-green-800 border-green-200",
    },
    {
      type: "neutral" as MoodType,
      label: "Sharing",
      icon: MessageCircle,
      color: "bg-gray-100 text-gray-800 border-gray-200",
    },
    {
      type: "support" as MoodType,
      label: "Seeking Support",
      icon: Heart,
      color: "bg-blue-100 text-blue-800 border-blue-200",
    },
  ]

  const handlePost = async () => {
    if (!content.trim()) return

    setIsPosting(true)

    // Simulate posting
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("New post:", { content, mood: selectedMood })
    setContent("")
    setSelectedMood("neutral")
    setIsPosting(false)
  }

  return (
    <Card className="hover:shadow-lg transition-all duration-200">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Avatar className="w-8 h-8">
            <AvatarFallback className="bg-primary/20">
              <User className="w-4 h-4" />
            </AvatarFallback>
          </Avatar>
          <span>Share with the Community</span>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Share your thoughts, experiences, or ask for support. This is a safe space..."
          className="min-h-[120px] transition-all focus:scale-105"
          disabled={isPosting}
        />

        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">How are you feeling?</label>
          <div className="flex flex-wrap gap-2">
            {moods.map((mood) => {
              const Icon = mood.icon
              return (
                <Button
                  key={mood.type}
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedMood(mood.type)}
                  className={cn(
                    "flex items-center space-x-2 hover:scale-105 transition-all bg-transparent",
                    selectedMood === mood.type && mood.color,
                  )}
                >
                  <Icon className="w-3 h-3" />
                  <span>{mood.label}</span>
                </Button>
              )
            })}
          </div>
        </div>

        <div className="flex justify-between items-center">
          <p className="text-xs text-muted-foreground">Your post will be shared anonymously with your nickname</p>
          <Button
            onClick={handlePost}
            disabled={!content.trim() || isPosting}
            className="hover:scale-105 transition-transform"
          >
            {isPosting ? (
              <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
            ) : (
              <Send className="w-4 h-4 mr-2" />
            )}
            {isPosting ? "Posting..." : "Share Post"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
