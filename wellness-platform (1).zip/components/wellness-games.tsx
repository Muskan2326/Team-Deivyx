"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import {
  Gamepad2,
  Play,
  Pause,
  RotateCcw,
  Heart,
  Zap,
  Target,
  Brain,
  Smile,
  Wind,
  Sparkles,
  Trophy,
  Timer,
} from "lucide-react"

interface Game {
  id: string
  title: string
  description: string
  category: "breathing" | "mindfulness" | "cognitive" | "mood"
  difficulty: "Easy" | "Medium" | "Hard"
  duration: string
  benefits: string[]
  icon: any
}

const games: Game[] = [
  {
    id: "breathing-circle",
    title: "Breathing Circle",
    description: "Follow the expanding circle to regulate your breathing and reduce anxiety",
    category: "breathing",
    difficulty: "Easy",
    duration: "2-10 min",
    benefits: ["Reduces anxiety", "Improves focus", "Calms nervous system"],
    icon: Wind,
  },
  {
    id: "gratitude-match",
    title: "Gratitude Memory Match",
    description: "Match positive affirmations and gratitude statements to boost mood",
    category: "mood",
    difficulty: "Easy",
    duration: "5-15 min",
    benefits: ["Increases positivity", "Builds gratitude", "Improves memory"],
    icon: Heart,
  },
  {
    id: "mindful-maze",
    title: "Mindful Maze",
    description: "Navigate through calming mazes while practicing mindfulness techniques",
    category: "mindfulness",
    difficulty: "Medium",
    duration: "10-20 min",
    benefits: ["Enhances focus", "Reduces stress", "Improves patience"],
    icon: Target,
  },
  {
    id: "emotion-wheel",
    title: "Emotion Recognition Wheel",
    description: "Learn to identify and understand different emotions through interactive exercises",
    category: "cognitive",
    difficulty: "Medium",
    duration: "8-15 min",
    benefits: ["Emotional awareness", "Self-understanding", "Better communication"],
    icon: Brain,
  },
  {
    id: "stress-bubble",
    title: "Stress Bubble Pop",
    description: "Pop stress bubbles while practicing relaxation techniques",
    category: "mood",
    difficulty: "Easy",
    duration: "3-8 min",
    benefits: ["Stress relief", "Instant relaxation", "Mood boost"],
    icon: Smile,
  },
  {
    id: "focus-flow",
    title: "Focus Flow Challenge",
    description: "Train your attention and concentration through engaging flow exercises",
    category: "cognitive",
    difficulty: "Hard",
    duration: "15-25 min",
    benefits: ["Improves concentration", "Enhances productivity", "Mental clarity"],
    icon: Zap,
  },
]

// Breathing Circle Game Component
function BreathingCircleGame({ onClose }: { onClose: () => void }) {
  const [isActive, setIsActive] = useState(false)
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale">("inhale")
  const [seconds, setSeconds] = useState(0)
  const [cycles, setCycles] = useState(0)
  const [breathPattern, setBreathPattern] = useState({ inhale: 4, hold: 4, exhale: 6 })

  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isActive) {
      interval = setInterval(() => {
        setSeconds((prev) => {
          const newSeconds = prev + 1

          if (phase === "inhale" && newSeconds >= breathPattern.inhale) {
            setPhase("hold")
            return 0
          } else if (phase === "hold" && newSeconds >= breathPattern.hold) {
            setPhase("exhale")
            return 0
          } else if (phase === "exhale" && newSeconds >= breathPattern.exhale) {
            setPhase("inhale")
            setCycles((prev) => prev + 1)
            return 0
          }

          return newSeconds
        })
      }, 1000)
    }

    return () => clearInterval(interval)
  }, [isActive, phase, breathPattern])

  const getCircleScale = () => {
    const progress = seconds / breathPattern[phase]
    if (phase === "inhale") return 0.5 + progress * 0.5
    if (phase === "exhale") return 1 - progress * 0.5
    return 1
  }

  const getPhaseText = () => {
    switch (phase) {
      case "inhale":
        return "Breathe In"
      case "hold":
        return "Hold"
      case "exhale":
        return "Breathe Out"
    }
  }

  return (
    <div className="flex flex-col items-center space-y-6 p-6">
      <div className="text-center space-y-2">
        <h3 className="text-2xl font-bold">Breathing Circle</h3>
        <p className="text-muted-foreground">Follow the circle and breathe deeply</p>
      </div>

      <div className="relative w-64 h-64 flex items-center justify-center">
        <div
          className="w-48 h-48 rounded-full bg-gradient-to-br from-blue-200 to-purple-200 border-4 border-blue-300 transition-transform duration-1000 ease-in-out flex items-center justify-center"
          style={{ transform: `scale(${getCircleScale()})` }}
        >
          <div className="text-center">
            <div className="text-xl font-semibold text-blue-800">{getPhaseText()}</div>
            <div className="text-sm text-blue-600">{breathPattern[phase] - seconds}s</div>
          </div>
        </div>
      </div>

      <div className="text-center space-y-2">
        <div className="text-lg font-medium">Cycles Completed: {cycles}</div>
        <div className="text-sm text-muted-foreground">
          Pattern: {breathPattern.inhale}s in • {breathPattern.hold}s hold • {breathPattern.exhale}s out
        </div>
      </div>

      <div className="flex space-x-4">
        <Button onClick={() => setIsActive(!isActive)} className="hover:scale-105 transition-transform">
          {isActive ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
          {isActive ? "Pause" : "Start"}
        </Button>
        <Button
          variant="outline"
          onClick={() => {
            setIsActive(false)
            setSeconds(0)
            setCycles(0)
            setPhase("inhale")
          }}
          className="hover:scale-105 transition-transform bg-transparent"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset
        </Button>
        <Button variant="outline" onClick={onClose} className="bg-transparent">
          Close
        </Button>
      </div>
    </div>
  )
}

// Gratitude Memory Match Game Component
function GratitudeMatchGame({ onClose }: { onClose: () => void }) {
  const [cards, setCards] = useState<Array<{ id: number; text: string; isFlipped: boolean; isMatched: boolean }>>([])
  const [flippedCards, setFlippedCards] = useState<number[]>([])
  const [matches, setMatches] = useState(0)
  const [moves, setMoves] = useState(0)

  const gratitudePairs = [
    "I am grateful for my health",
    "I appreciate my family",
    "I value my friendships",
    "I'm thankful for today",
    "I cherish small moments",
    "I appreciate my growth",
  ]

  useEffect(() => {
    initializeGame()
  }, [])

  const initializeGame = () => {
    const gameCards = [...gratitudePairs, ...gratitudePairs]
      .sort(() => Math.random() - 0.5)
      .map((text, index) => ({
        id: index,
        text,
        isFlipped: false,
        isMatched: false,
      }))
    setCards(gameCards)
    setMatches(0)
    setMoves(0)
    setFlippedCards([])
  }

  const handleCardClick = (cardId: number) => {
    if (flippedCards.length === 2) return
    if (cards[cardId].isFlipped || cards[cardId].isMatched) return

    const newCards = [...cards]
    newCards[cardId].isFlipped = true
    setCards(newCards)

    const newFlippedCards = [...flippedCards, cardId]
    setFlippedCards(newFlippedCards)

    if (newFlippedCards.length === 2) {
      setMoves((prev) => prev + 1)
      const [first, second] = newFlippedCards

      if (cards[first].text === cards[second].text) {
        setTimeout(() => {
          const matchedCards = [...cards]
          matchedCards[first].isMatched = true
          matchedCards[second].isMatched = true
          setCards(matchedCards)
          setMatches((prev) => prev + 1)
          setFlippedCards([])
        }, 1000)
      } else {
        setTimeout(() => {
          const resetCards = [...cards]
          resetCards[first].isFlipped = false
          resetCards[second].isFlipped = false
          setCards(resetCards)
          setFlippedCards([])
        }, 1000)
      }
    }
  }

  return (
    <div className="flex flex-col items-center space-y-6 p-6">
      <div className="text-center space-y-2">
        <h3 className="text-2xl font-bold">Gratitude Memory Match</h3>
        <p className="text-muted-foreground">Match the gratitude statements to boost positivity</p>
      </div>

      <div className="flex space-x-8 text-center">
        <div>
          <div className="text-2xl font-bold text-green-600">{matches}</div>
          <div className="text-sm text-muted-foreground">Matches</div>
        </div>
        <div>
          <div className="text-2xl font-bold text-blue-600">{moves}</div>
          <div className="text-sm text-muted-foreground">Moves</div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3 max-w-2xl">
        {cards.map((card) => (
          <div
            key={card.id}
            onClick={() => handleCardClick(card.id)}
            className={`w-24 h-24 rounded-lg border-2 cursor-pointer transition-all duration-300 flex items-center justify-center text-xs font-medium text-center p-2 ${
              card.isMatched
                ? "bg-green-100 border-green-300 text-green-800"
                : card.isFlipped
                  ? "bg-blue-100 border-blue-300 text-blue-800"
                  : "bg-gray-100 border-gray-300 hover:bg-gray-200"
            }`}
          >
            {card.isFlipped || card.isMatched ? card.text : "?"}
          </div>
        ))}
      </div>

      <div className="flex space-x-4">
        <Button onClick={initializeGame} className="hover:scale-105 transition-transform">
          <RotateCcw className="w-4 h-4 mr-2" />
          New Game
        </Button>
        <Button variant="outline" onClick={onClose} className="bg-transparent">
          Close
        </Button>
      </div>

      {matches === gratitudePairs.length && (
        <div className="text-center space-y-2 animate-bounce">
          <Trophy className="w-12 h-12 text-yellow-500 mx-auto" />
          <div className="text-lg font-bold text-green-600">Congratulations!</div>
          <div className="text-sm text-muted-foreground">You completed the game in {moves} moves!</div>
        </div>
      )}
    </div>
  )
}

export function WellnessGames() {
  const [selectedGame, setSelectedGame] = useState<Game | null>(null)
  const [categoryFilter, setCategoryFilter] = useState<string>("all")

  const filteredGames = games.filter((game) => categoryFilter === "all" || game.category === categoryFilter)

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "breathing":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "mindfulness":
        return "bg-green-100 text-green-800 border-green-200"
      case "cognitive":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "mood":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-green-100 text-green-800"
      case "Medium":
        return "bg-yellow-100 text-yellow-800"
      case "Hard":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const renderGameContent = (game: Game) => {
    switch (game.id) {
      case "breathing-circle":
        return <BreathingCircleGame onClose={() => setSelectedGame(null)} />
      case "gratitude-match":
        return <GratitudeMatchGame onClose={() => setSelectedGame(null)} />
      default:
        return (
          <div className="text-center p-8">
            <div className="text-6xl mb-4">🎮</div>
            <h3 className="text-xl font-bold mb-2">{game.title}</h3>
            <p className="text-muted-foreground mb-4">This game is coming soon!</p>
            <Button onClick={() => setSelectedGame(null)}>Close</Button>
          </div>
        )
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Gamepad2 className="w-5 h-5 text-primary" />
            <span>Wellness Games</span>
          </CardTitle>
          <CardDescription>
            Interactive games designed to improve mental wellness through fun, therapeutic activities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={categoryFilter} onValueChange={setCategoryFilter} className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="all">All Games</TabsTrigger>
              <TabsTrigger value="breathing">Breathing</TabsTrigger>
              <TabsTrigger value="mindfulness">Mindfulness</TabsTrigger>
              <TabsTrigger value="cognitive">Cognitive</TabsTrigger>
              <TabsTrigger value="mood">Mood</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardContent>
      </Card>

      {/* Games Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGames.map((game) => {
          const IconComponent = game.icon
          return (
            <Card
              key={game.id}
              className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02] cursor-pointer"
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                      <IconComponent className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{game.title}</CardTitle>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" className={getCategoryColor(game.category)}>
                          {game.category}
                        </Badge>
                        <Badge variant="outline" className={getDifficultyColor(game.difficulty)}>
                          {game.difficulty}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                    <Timer className="w-3 h-3" />
                    <span>{game.duration}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground leading-relaxed">{game.description}</p>

                <div>
                  <h4 className="text-sm font-medium mb-2">Benefits:</h4>
                  <div className="flex flex-wrap gap-1">
                    {game.benefits.map((benefit) => (
                      <Badge key={benefit} variant="secondary" className="text-xs">
                        {benefit}
                      </Badge>
                    ))}
                  </div>
                </div>

                <Dialog open={selectedGame?.id === game.id} onOpenChange={(open) => !open && setSelectedGame(null)}>
                  <DialogTrigger asChild>
                    <Button
                      onClick={() => setSelectedGame(game)}
                      className="w-full hover:scale-105 transition-transform"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Play Game
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                    {selectedGame && renderGameContent(selectedGame)}
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Daily Challenge */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-purple-800">
            <Sparkles className="w-5 h-5" />
            <span>Daily Wellness Challenge</span>
          </CardTitle>
          <CardDescription className="text-purple-700">
            Complete today's challenge to earn points and build healthy habits
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 bg-white rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Wind className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h4 className="font-medium">5-Minute Breathing Exercise</h4>
                <p className="text-sm text-muted-foreground">Complete 10 breathing cycles</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm font-medium text-purple-600">+50 points</div>
              <Progress value={30} className="w-24 mt-1" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
