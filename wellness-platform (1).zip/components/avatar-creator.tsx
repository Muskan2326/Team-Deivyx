"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Shuffle, Save, RotateCcw } from "lucide-react"

interface AvatarConfig {
  skinTone: number
  hairStyle: number
  hairColor: number
  eyeColor: number
  outfit: number
  accessory: number
}

const skinTones = ["#FDBCB4", "#F1C27D", "#E0AC69", "#C68642", "#8D5524", "#654321"]
const hairStyles = ["Short", "Long", "Curly", "Wavy", "Buzz Cut", "Ponytail"]
const hairColors = ["#2C1B18", "#724C34", "#8B4513", "#D2691E", "#FFD700", "#FF6347"]
const eyeColors = ["#8B4513", "#228B22", "#4169E1", "#32CD32", "#9932CC", "#FF1493"]
const outfits = ["Casual", "Formal", "Sporty", "Artistic", "Cozy", "Professional"]
const accessories = ["None", "Glasses", "Hat", "Earrings", "Necklace", "Watch"]

export function AvatarCreator() {
  const [config, setConfig] = useState<AvatarConfig>({
    skinTone: 0,
    hairStyle: 0,
    hairColor: 0,
    eyeColor: 0,
    outfit: 0,
    accessory: 0,
  })
  const [isAnimating, setIsAnimating] = useState(false)
  const avatarRef = useRef<HTMLDivElement>(null)

  const randomizeAvatar = () => {
    setIsAnimating(true)
    setConfig({
      skinTone: Math.floor(Math.random() * skinTones.length),
      hairStyle: Math.floor(Math.random() * hairStyles.length),
      hairColor: Math.floor(Math.random() * hairColors.length),
      eyeColor: Math.floor(Math.random() * eyeColors.length),
      outfit: Math.floor(Math.random() * outfits.length),
      accessory: Math.floor(Math.random() * accessories.length),
    })
    setTimeout(() => setIsAnimating(false), 500)
  }

  const resetAvatar = () => {
    setConfig({
      skinTone: 0,
      hairStyle: 0,
      hairColor: 0,
      eyeColor: 0,
      outfit: 0,
      accessory: 0,
    })
  }

  const saveAvatar = () => {
    // In a real app, this would save to a database
    console.log("Avatar saved:", config)
    // Show success message
  }

  // Simulate avatar reactions
  useEffect(() => {
    const interval = setInterval(() => {
      if (avatarRef.current && !isAnimating) {
        avatarRef.current.style.transform = "scale(1.05)"
        setTimeout(() => {
          if (avatarRef.current) {
            avatarRef.current.style.transform = "scale(1)"
          }
        }, 200)
      }
    }, 3000)

    return () => clearInterval(interval)
  }, [isAnimating])

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      {/* Avatar Preview */}
      <div className="flex flex-col items-center space-y-6">
        <Card className="w-full max-w-sm">
          <CardContent className="p-6">
            <div
              ref={avatarRef}
              className={`w-48 h-48 mx-auto rounded-full border-4 border-primary/20 flex items-center justify-center transition-all duration-300 ${
                isAnimating ? "animate-spin" : "hover:scale-105"
              }`}
              style={{
                backgroundColor: skinTones[config.skinTone],
                boxShadow: "0 8px 32px rgba(164, 215, 225, 0.3)",
              }}
            >
              {/* Simplified avatar representation */}
              <div className="text-center">
                <div
                  className="w-4 h-4 rounded-full mx-auto mb-2"
                  style={{ backgroundColor: eyeColors[config.eyeColor] }}
                />
                <div
                  className="w-16 h-8 rounded-t-full mx-auto mb-2"
                  style={{ backgroundColor: hairColors[config.hairColor] }}
                />
                <div className="text-xs font-medium text-gray-700">{hairStyles[config.hairStyle]}</div>
                <div className="text-xs text-gray-600 mt-1">{outfits[config.outfit]}</div>
                {accessories[config.accessory] !== "None" && (
                  <Badge variant="secondary" className="mt-2 text-xs">
                    {accessories[config.accessory]}
                  </Badge>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex space-x-2">
          <Button
            onClick={randomizeAvatar}
            variant="outline"
            className="hover:scale-105 transition-transform bg-transparent"
          >
            <Shuffle className="w-4 h-4 mr-2" />
            Randomize
          </Button>
          <Button
            onClick={resetAvatar}
            variant="outline"
            className="hover:scale-105 transition-transform bg-transparent"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          <Button onClick={saveAvatar} className="hover:scale-105 transition-transform">
            <Save className="w-4 h-4 mr-2" />
            Save Avatar
          </Button>
        </div>
      </div>

      {/* Customization Controls */}
      <div className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Customize Your Look</h3>

          {/* Skin Tone */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Skin Tone</label>
            <div className="flex space-x-2">
              {skinTones.map((tone, index) => (
                <button
                  key={index}
                  onClick={() => setConfig({ ...config, skinTone: index })}
                  className={`w-8 h-8 rounded-full border-2 transition-all hover:scale-110 ${
                    config.skinTone === index ? "border-primary shadow-lg" : "border-gray-300"
                  }`}
                  style={{ backgroundColor: tone }}
                />
              ))}
            </div>
          </div>

          {/* Hair Style */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Hair Style</label>
            <Slider
              value={[config.hairStyle]}
              onValueChange={(value) => setConfig({ ...config, hairStyle: value[0] })}
              max={hairStyles.length - 1}
              step={1}
              className="w-full"
            />
            <div className="text-sm text-muted-foreground text-center">{hairStyles[config.hairStyle]}</div>
          </div>

          {/* Hair Color */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Hair Color</label>
            <div className="flex space-x-2">
              {hairColors.map((color, index) => (
                <button
                  key={index}
                  onClick={() => setConfig({ ...config, hairColor: index })}
                  className={`w-8 h-8 rounded-full border-2 transition-all hover:scale-110 ${
                    config.hairColor === index ? "border-primary shadow-lg" : "border-gray-300"
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>

          {/* Eye Color */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Eye Color</label>
            <div className="flex space-x-2">
              {eyeColors.map((color, index) => (
                <button
                  key={index}
                  onClick={() => setConfig({ ...config, eyeColor: index })}
                  className={`w-8 h-8 rounded-full border-2 transition-all hover:scale-110 ${
                    config.eyeColor === index ? "border-primary shadow-lg" : "border-gray-300"
                  }`}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
          </div>

          {/* Outfit */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Outfit Style</label>
            <Slider
              value={[config.outfit]}
              onValueChange={(value) => setConfig({ ...config, outfit: value[0] })}
              max={outfits.length - 1}
              step={1}
              className="w-full"
            />
            <div className="text-sm text-muted-foreground text-center">{outfits[config.outfit]}</div>
          </div>

          {/* Accessories */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Accessories</label>
            <Slider
              value={[config.accessory]}
              onValueChange={(value) => setConfig({ ...config, accessory: value[0] })}
              max={accessories.length - 1}
              step={1}
              className="w-full"
            />
            <div className="text-sm text-muted-foreground text-center">{accessories[config.accessory]}</div>
          </div>
        </div>
      </div>
    </div>
  )
}
