"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageCircle, Clock, Users, Search, Star, MapPin, Calendar } from "lucide-react"

interface Volunteer {
  id: string
  name: string
  specialties: string[]
  status: "online" | "busy" | "offline"
  responseTime: string
  rating: number
  location: string
  languages: string[]
  experience: string
  joinedDate: Date
  totalChats: number
}

interface PeerUser {
  id: string
  nickname: string
  status: "online" | "away" | "offline"
  mood: "positive" | "neutral" | "support"
  interests: string[]
  joinedDate: Date
  supportGiven: number
  isVerified: boolean
}

const volunteers: Volunteer[] = [
  {
    id: "1",
    name: "Sarah M.",
    specialties: ["Anxiety", "Depression", "Stress Management"],
    status: "online",
    responseTime: "Usually responds in 5 minutes",
    rating: 4.9,
    location: "US East Coast",
    languages: ["English", "Spanish"],
    experience: "3 years peer support",
    joinedDate: new Date(2021, 5, 15),
    totalChats: 1247,
  },
  {
    id: "2",
    name: "Alex K.",
    specialties: ["Grief", "Trauma", "Relationship Issues"],
    status: "online",
    responseTime: "Usually responds in 10 minutes",
    rating: 4.8,
    location: "UK",
    languages: ["English"],
    experience: "5 years counseling background",
    joinedDate: new Date(2020, 2, 8),
    totalChats: 2156,
  },
  {
    id: "3",
    name: "Jordan L.",
    specialties: ["LGBTQ+ Support", "Identity", "Self-Esteem"],
    status: "busy",
    responseTime: "Usually responds in 30 minutes",
    rating: 4.9,
    location: "Canada",
    languages: ["English", "French"],
    experience: "2 years community support",
    joinedDate: new Date(2022, 1, 20),
    totalChats: 892,
  },
  {
    id: "4",
    name: "Morgan R.",
    specialties: ["Addiction Recovery", "Mindfulness", "Coping Skills"],
    status: "offline",
    responseTime: "Usually responds in 2 hours",
    rating: 4.7,
    location: "Australia",
    languages: ["English"],
    experience: "4 years recovery support",
    joinedDate: new Date(2021, 8, 12),
    totalChats: 1634,
  },
  {
    id: "5",
    name: "Maya P.",
    specialties: ["Student Support", "Academic Stress", "Social Anxiety"],
    status: "online",
    responseTime: "Usually responds in 8 minutes",
    rating: 4.8,
    location: "US West Coast",
    languages: ["English", "Hindi"],
    experience: "2 years student counseling",
    joinedDate: new Date(2022, 9, 5),
    totalChats: 743,
  },
]

const peerUsers: PeerUser[] = [
  {
    id: "p1",
    nickname: "SunnyDays",
    status: "online",
    mood: "positive",
    interests: ["Meditation", "Journaling", "Nature"],
    joinedDate: new Date(2023, 1, 15),
    supportGiven: 45,
    isVerified: true,
  },
  {
    id: "p2",
    nickname: "QuietStrength",
    status: "online",
    mood: "support",
    interests: ["Anxiety Support", "Breathing Exercises", "Art Therapy"],
    joinedDate: new Date(2022, 11, 8),
    supportGiven: 78,
    isVerified: true,
  },
  {
    id: "p3",
    nickname: "MindfulMoments",
    status: "away",
    mood: "positive",
    interests: ["Mindfulness", "Yoga", "Reading"],
    joinedDate: new Date(2023, 3, 22),
    supportGiven: 32,
    isVerified: false,
  },
  {
    id: "p4",
    nickname: "HealingHeart",
    status: "online",
    mood: "neutral",
    interests: ["Grief Support", "Music Therapy", "Writing"],
    joinedDate: new Date(2022, 7, 14),
    supportGiven: 156,
    isVerified: true,
  },
]

export function PeerSupport() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [specialtyFilter, setSpecialtyFilter] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("rating")
  const [selectedVolunteer, setSelectedVolunteer] = useState<string | null>(null)

  const filteredVolunteers = useMemo(() => {
    return volunteers
      .filter((volunteer) => {
        const matchesSearch =
          volunteer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          volunteer.specialties.some((s) => s.toLowerCase().includes(searchTerm.toLowerCase()))
        const matchesStatus = statusFilter === "all" || volunteer.status === statusFilter
        const matchesSpecialty =
          specialtyFilter === "all" ||
          volunteer.specialties.some((s) => s.toLowerCase().includes(specialtyFilter.toLowerCase()))

        return matchesSearch && matchesStatus && matchesSpecialty
      })
      .sort((a, b) => {
        switch (sortBy) {
          case "rating":
            return b.rating - a.rating
          case "experience":
            return b.totalChats - a.totalChats
          case "availability":
            const statusOrder = { online: 0, busy: 1, offline: 2 }
            return statusOrder[a.status] - statusOrder[b.status]
          default:
            return 0
        }
      })
  }, [searchTerm, statusFilter, specialtyFilter, sortBy])

  const filteredPeerUsers = useMemo(() => {
    return peerUsers.filter((user) => {
      const matchesSearch =
        user.nickname.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.interests.some((i) => i.toLowerCase().includes(searchTerm.toLowerCase()))
      const matchesStatus = statusFilter === "all" || user.status === statusFilter

      return matchesSearch && matchesStatus
    })
  }, [searchTerm, statusFilter])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-green-500"
      case "busy":
      case "away":
        return "bg-yellow-500"
      case "offline":
        return "bg-gray-400"
      default:
        return "bg-gray-400"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "online":
        return "Available Now"
      case "busy":
        return "Busy"
      case "away":
        return "Away"
      case "offline":
        return "Offline"
      default:
        return "Unknown"
    }
  }

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case "positive":
        return "bg-green-100 text-green-800 border-green-200"
      case "support":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "neutral":
        return "bg-gray-100 text-gray-800 border-gray-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const startChat = (id: string, type: "volunteer" | "peer") => {
    setSelectedVolunteer(id)
    console.log(`Starting chat with ${type}:`, id)
  }

  return (
    <div className="space-y-6">
      {/* Search and Filter Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-primary" />
            <span>Find Support</span>
          </CardTitle>
          <CardDescription>Search for volunteers or peer supporters based on your needs</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search by name, specialty, or interest..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="online">Online</SelectItem>
                <SelectItem value="busy">Busy</SelectItem>
                <SelectItem value="offline">Offline</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">Highest Rated</SelectItem>
                <SelectItem value="experience">Most Experienced</SelectItem>
                <SelectItem value="availability">Availability</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="volunteers" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="volunteers">Professional Volunteers</TabsTrigger>
          <TabsTrigger value="peers">Peer Support</TabsTrigger>
        </TabsList>

        <TabsContent value="volunteers" className="space-y-4">
          <div className="grid gap-4">
            {filteredVolunteers.map((volunteer) => (
              <Card
                key={volunteer.id}
                className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02] cursor-pointer"
                onClick={() => startChat(volunteer.id, "volunteer")}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <Avatar className="w-12 h-12">
                          <AvatarFallback className="bg-primary/20 text-primary font-semibold">
                            {volunteer.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div
                          className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${getStatusColor(
                            volunteer.status,
                          )}`}
                        />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <CardTitle className="text-lg">{volunteer.name}</CardTitle>
                          <div className="flex items-center space-x-1">
                            <Star className="w-3 h-3 fill-current text-yellow-500" />
                            <span className="text-sm font-medium">{volunteer.rating}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge
                            variant="outline"
                            className={volunteer.status === "online" ? "border-green-200 text-green-800" : ""}
                          >
                            {getStatusText(volunteer.status)}
                          </Badge>
                          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                            <MapPin className="w-3 h-3" />
                            <span>{volunteer.location}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <Button
                      variant={volunteer.status === "online" ? "default" : "outline"}
                      size="sm"
                      className="hover:scale-105 transition-transform"
                      disabled={volunteer.status === "offline"}
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      {volunteer.status === "online" ? "Chat Now" : "Join Queue"}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-1">
                      {volunteer.specialties.map((specialty) => (
                        <Badge key={specialty} variant="secondary" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{volunteer.responseTime}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <MessageCircle className="w-3 h-3" />
                        <span>{volunteer.totalChats} total chats</span>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {volunteer.experience} • Languages: {volunteer.languages.join(", ")}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="peers" className="space-y-4">
          <div className="grid gap-4">
            {filteredPeerUsers.map((user) => (
              <Card
                key={user.id}
                className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02] cursor-pointer"
                onClick={() => startChat(user.id, "peer")}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className="bg-secondary/20">
                            {user.nickname.slice(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div
                          className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(
                            user.status,
                          )}`}
                        />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="font-semibold">{user.nickname}</h3>
                          {user.isVerified && (
                            <Badge variant="outline" className="text-xs border-blue-200 text-blue-800">
                              Verified
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className={getMoodColor(user.mood)}>
                            {user.mood === "positive"
                              ? "Feeling Good"
                              : user.mood === "support"
                                ? "Seeking Support"
                                : "Neutral"}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{user.supportGiven} people helped</span>
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="hover:scale-105 transition-transform bg-transparent"
                      disabled={user.status === "offline"}
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Connect
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-1">
                      {user.interests.map((interest) => (
                        <Badge key={interest} variant="secondary" className="text-xs">
                          {interest}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                      <Calendar className="w-3 h-3" />
                      <span>Member since {user.joinedDate.toLocaleDateString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Group Support Sessions */}
      <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-primary" />
            <span>Group Support Sessions</span>
          </CardTitle>
          <CardDescription>Join scheduled group sessions for peer support and guided discussions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-background rounded-lg">
              <div>
                <h4 className="font-medium">Anxiety Support Circle</h4>
                <p className="text-sm text-muted-foreground">Today at 7:00 PM • 8 participants</p>
              </div>
              <Button size="sm" className="hover:scale-105 transition-transform">
                Join
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-background rounded-lg">
              <div>
                <h4 className="font-medium">Mindfulness & Meditation</h4>
                <p className="text-sm text-muted-foreground">Tomorrow at 6:00 AM • 12 participants</p>
              </div>
              <Button size="sm" variant="outline" className="hover:scale-105 transition-transform bg-transparent">
                Schedule
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-background rounded-lg">
              <div>
                <h4 className="font-medium">LGBTQ+ Safe Space</h4>
                <p className="text-sm text-muted-foreground">Friday at 8:00 PM • 6 participants</p>
              </div>
              <Button size="sm" variant="outline" className="hover:scale-105 transition-transform bg-transparent">
                Join Waitlist
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
