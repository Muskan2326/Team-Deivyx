"use client"

import { useState, useRef, useEffect } from "react"
import { Volume2, VolumeX, Play, Pause } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"

export function BackgroundAudio() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [volume, setVolume] = useState([0.3])
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume[0]
    }
  }, [volume])

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  return (
    <div className="fixed bottom-4 right-4 z-50 bg-white/80 backdrop-blur-sm rounded-full p-3 shadow-lg border border-lavender/20">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={togglePlay} className="h-8 w-8 p-0 hover:bg-lavender/20">
          {isPlaying ? <Pause className="h-4 w-4 text-lavender" /> : <Play className="h-4 w-4 text-lavender" />}
        </Button>

        <Button variant="ghost" size="sm" onClick={toggleMute} className="h-8 w-8 p-0 hover:bg-lavender/20">
          {isMuted ? <VolumeX className="h-4 w-4 text-lavender" /> : <Volume2 className="h-4 w-4 text-lavender" />}
        </Button>

        <div className="w-16">
          <Slider value={volume} onValueChange={setVolume} max={1} step={0.1} className="w-full" />
        </div>
      </div>

      <audio ref={audioRef} loop preload="auto" onPlay={() => setIsPlaying(true)} onPause={() => setIsPlaying(false)}>
        <source src="/placeholder.mp3?query=calming alpha waves meditation music" type="audio/mpeg" />
        Your browser does not support the audio element.
      </audio>
    </div>
  )
}
