"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { Activity } from "lucide-react"

const assessmentData = [
  { name: "PHQ-9", score: 8, maxScore: 27, category: "Depression", color: "#a4d7e1" },
  { name: "GAD-7", score: 6, maxScore: 21, category: "Anxiety", color: "#ffb3b3" },
  { name: "GHQ", score: 4, maxScore: 12, category: "General Health", color: "#ffe5d9" },
]

const activityData = [
  { name: "Surveys", completed: 12, target: 15 },
  { name: "Check-ins", completed: 28, target: 30 },
  { name: "Community", completed: 8, target: 10 },
  { name: "AI Chats", completed: 15, target: 20 },
]

const moodDistribution = [
  { name: "Great", value: 25, color: "#10b981" },
  { name: "Good", value: 35, color: "#a4d7e1" },
  { name: "Okay", value: 25, color: "#fbbf24" },
  { name: "Low", value: 15, color: "#f87171" },
]

export function WellnessStats() {
  const [activeTab, setActiveTab] = useState<"assessments" | "activity" | "mood">("assessments")

  return (
    <Card className="animate-slide-in">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Activity className="w-5 h-5 text-primary" />
          <span>Wellness Analytics</span>
        </CardTitle>
        <CardDescription>Detailed insights into your mental health journey</CardDescription>
        <div className="flex space-x-2 mt-4">
          <Button
            variant={activeTab === "assessments" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTab("assessments")}
            className="hover:scale-105 transition-transform"
          >
            Assessments
          </Button>
          <Button
            variant={activeTab === "activity" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTab("activity")}
            className="hover:scale-105 transition-transform"
          >
            Activity
          </Button>
          <Button
            variant={activeTab === "mood" ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveTab("mood")}
            className="hover:scale-105 transition-transform"
          >
            Mood Distribution
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {activeTab === "assessments" && (
          <div className="space-y-6">
            <div className="text-sm text-muted-foreground mb-4">Latest assessment scores and trends</div>
            {assessmentData.map((assessment, index) => (
              <div
                key={assessment.name}
                className="space-y-2 animate-slide-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium text-foreground">{assessment.name}</div>
                    <div className="text-sm text-muted-foreground">{assessment.category}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-foreground">
                      {assessment.score}/{assessment.maxScore}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {Math.round((assessment.score / assessment.maxScore) * 100)}%
                    </div>
                  </div>
                </div>
                <Progress
                  value={(assessment.score / assessment.maxScore) * 100}
                  className="h-2"
                  style={{ "--progress-foreground": assessment.color } as React.CSSProperties}
                />
              </div>
            ))}
          </div>
        )}

        {activeTab === "activity" && (
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activityData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="name" stroke="#6b7280" />
                <YAxis stroke="#6b7280" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#f9f2f9",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="completed" fill="#a4d7e1" radius={[4, 4, 0, 0]} animationDuration={1000} />
                <Bar dataKey="target" fill="#ffb3b3" radius={[4, 4, 0, 0]} animationDuration={1000} opacity={0.3} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {activeTab === "mood" && (
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={moodDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                  animationDuration={1000}
                >
                  {moodDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#f9f2f9",
                    border: "1px solid #e5e7eb",
                    borderRadius: "8px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex justify-center space-x-4 mt-4">
              {moodDistribution.map((item) => (
                <div key={item.name} className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-sm text-muted-foreground">
                    {item.name} ({item.value}%)
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
