"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Send, User, Mail } from "lucide-react"

export function ContactForm() {
  const [formData, setFormData] = useState({
    userId: "",
    subject: "",
    category: "",
    message: "",
    urgency: "normal",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("Contact form submitted:", formData)
    setIsSubmitting(false)

    // Reset form
    setFormData({
      userId: "",
      subject: "",
      category: "",
      message: "",
      urgency: "normal",
    })
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData({ ...formData, [field]: value })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="userId" className="flex items-center space-x-2">
            <User className="w-4 h-4 text-primary" />
            <span>Your User ID</span>
          </Label>
          <Input
            id="userId"
            type="text"
            placeholder="Enter your User ID"
            value={formData.userId}
            onChange={(e) => handleInputChange("userId", e.target.value)}
            className="transition-all focus:scale-105"
            required
          />
          <p className="text-xs text-muted-foreground">This helps us provide personalized support</p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="urgency">Priority Level</Label>
          <Select value={formData.urgency} onValueChange={(value) => handleInputChange("urgency", value)}>
            <SelectTrigger className="transition-all focus:scale-105">
              <SelectValue placeholder="Select urgency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low - General inquiry</SelectItem>
              <SelectItem value="normal">Normal - Standard support</SelectItem>
              <SelectItem value="high">High - Urgent assistance needed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="category">Category</Label>
          <Select value={formData.category} onValueChange={(value) => handleInputChange("category", value)}>
            <SelectTrigger className="transition-all focus:scale-105">
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="technical">Technical Support</SelectItem>
              <SelectItem value="mental-health">Mental Health Resources</SelectItem>
              <SelectItem value="community">Community Guidelines</SelectItem>
              <SelectItem value="privacy">Privacy & Safety</SelectItem>
              <SelectItem value="feedback">Feedback & Suggestions</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="subject" className="flex items-center space-x-2">
            <Mail className="w-4 h-4 text-primary" />
            <span>Subject</span>
          </Label>
          <Input
            id="subject"
            type="text"
            placeholder="Brief description of your inquiry"
            value={formData.subject}
            onChange={(e) => handleInputChange("subject", e.target.value)}
            className="transition-all focus:scale-105"
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="message">Message</Label>
        <Textarea
          id="message"
          placeholder="Please describe your question or concern in detail. The more information you provide, the better we can assist you."
          value={formData.message}
          onChange={(e) => handleInputChange("message", e.target.value)}
          className="min-h-[120px] transition-all focus:scale-105"
          required
        />
      </div>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <h4 className="font-medium text-blue-800 mb-2">Response Time</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• High priority: Within 2 hours</li>
            <li>• Normal priority: Within 24 hours</li>
            <li>• Low priority: Within 48 hours</li>
          </ul>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          type="submit"
          disabled={isSubmitting || !formData.userId || !formData.subject || !formData.message}
          className="hover:scale-105 transition-transform"
          size="lg"
        >
          {isSubmitting ? (
            <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
          ) : (
            <Send className="w-4 h-4 mr-2" />
          )}
          {isSubmitting ? "Sending..." : "Send Message"}
        </Button>
      </div>
    </form>
  )
}
