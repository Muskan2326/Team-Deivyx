"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, MessageCircle, ClipboardList, Users, TrendingUp } from "lucide-react"

const activities = [
  {
    id: 1,
    type: "mood",
    title: "Daily mood check-in completed",
    description: "Mood: 8/10, Energy: 7/10",
    time: "2 hours ago",
    icon: CheckCircle,
    color: "text-green-600",
  },
  {
    id: 2,
    type: "chat",
    title: "AI conversation session",
    description: "Discussed anxiety management techniques",
    time: "5 hours ago",
    icon: MessageCircle,
    color: "text-blue-600",
  },
  {
    id: 3,
    type: "assessment",
    title: "GAD-7 assessment completed",
    description: "Score: 6/21 (Mild anxiety)",
    time: "1 day ago",
    icon: ClipboardList,
    color: "text-purple-600",
  },
  {
    id: 4,
    type: "community",
    title: "Posted in community",
    description: "Shared progress update",
    time: "2 days ago",
    icon: Users,
    color: "text-orange-600",
  },
  {
    id: 5,
    type: "milestone",
    title: "7-day streak achieved!",
    description: "Consistent daily check-ins",
    time: "3 days ago",
    icon: TrendingUp,
    color: "text-green-600",
  },
]

export function RecentActivity() {
  return (
    <Card className="animate-slide-in">
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>Your latest wellness activities and milestones</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity, index) => {
          const Icon = activity.icon
          return (
            <div
              key={activity.id}
              className="flex items-start space-x-3 animate-slide-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center flex-shrink-0">
                <Icon className={`w-4 h-4 ${activity.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-foreground text-sm">{activity.title}</div>
                <div className="text-sm text-muted-foreground">{activity.description}</div>
                <div className="text-xs text-muted-foreground mt-1">{activity.time}</div>
              </div>
            </div>
          )
        })}

        <div className="pt-4 border-t border-border">
          <div className="text-center">
            <Badge variant="outline" className="animate-gentle-pulse">
              <TrendingUp className="w-3 h-3 mr-1" />
              Overall wellness trend: Improving
            </Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
