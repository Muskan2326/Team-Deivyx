"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Save, Eye, EyeOff, User, Lock, FileText } from "lucide-react"

export function ProfileForm() {
  const [formData, setFormData] = useState({
    userId: "",
    nickname: "",
    password: "",
    confirmPassword: "",
    bio: "",
    notifications: true,
    publicProfile: false,
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("Profile updated:", formData)
    setIsLoading(false)
  }

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData({ ...formData, [field]: value })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        {/* User ID */}
        <div className="space-y-2">
          <Label htmlFor="userId" className="flex items-center space-x-2">
            <User className="w-4 h-4 text-primary" />
            <span>User ID</span>
          </Label>
          <Input
            id="userId"
            type="text"
            placeholder="Enter your unique user ID"
            value={formData.userId}
            onChange={(e) => handleInputChange("userId", e.target.value)}
            className="transition-all focus:scale-105"
          />
          <p className="text-xs text-muted-foreground">This will be your unique identifier in the community</p>
        </div>

        {/* Nickname */}
        <div className="space-y-2">
          <Label htmlFor="nickname" className="flex items-center space-x-2">
            <User className="w-4 h-4 text-secondary" />
            <span>Nickname</span>
          </Label>
          <Input
            id="nickname"
            type="text"
            placeholder="Choose a friendly nickname"
            value={formData.nickname}
            onChange={(e) => handleInputChange("nickname", e.target.value)}
            className="transition-all focus:scale-105"
          />
          <p className="text-xs text-muted-foreground">This is how others will see you in the community</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Password */}
        <div className="space-y-2">
          <Label htmlFor="password" className="flex items-center space-x-2">
            <Lock className="w-4 h-4 text-primary" />
            <span>Password</span>
          </Label>
          <div className="relative">
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="Enter your password"
              value={formData.password}
              onChange={(e) => handleInputChange("password", e.target.value)}
              className="pr-10 transition-all focus:scale-105"
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
              onClick={() => setShowPassword(!showPassword)}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Confirm Password */}
        <div className="space-y-2">
          <Label htmlFor="confirmPassword" className="flex items-center space-x-2">
            <Lock className="w-4 h-4 text-secondary" />
            <span>Confirm Password</span>
          </Label>
          <div className="relative">
            <Input
              id="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              placeholder="Confirm your password"
              value={formData.confirmPassword}
              onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
              className="pr-10 transition-all focus:scale-105"
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
            >
              {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Bio */}
      <div className="space-y-2">
        <Label htmlFor="bio" className="flex items-center space-x-2">
          <FileText className="w-4 h-4 text-primary" />
          <span>Bio (Optional)</span>
        </Label>
        <Textarea
          id="bio"
          placeholder="Tell us a bit about yourself and your wellness journey..."
          value={formData.bio}
          onChange={(e) => handleInputChange("bio", e.target.value)}
          className="min-h-[100px] transition-all focus:scale-105"
        />
        <p className="text-xs text-muted-foreground">
          Share what feels comfortable - this helps others connect with you
        </p>
      </div>

      {/* Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Privacy & Notifications</CardTitle>
          <CardDescription>Manage how you interact with the community</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="notifications">Enable Notifications</Label>
              <p className="text-sm text-muted-foreground">
                Receive updates about community activity and wellness tips
              </p>
            </div>
            <Switch
              id="notifications"
              checked={formData.notifications}
              onCheckedChange={(checked) => handleInputChange("notifications", checked)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="publicProfile">Public Profile</Label>
              <p className="text-sm text-muted-foreground">Allow others to view your profile and wellness journey</p>
            </div>
            <Switch
              id="publicProfile"
              checked={formData.publicProfile}
              onCheckedChange={(checked) => handleInputChange("publicProfile", checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex justify-end">
        <Button type="submit" disabled={isLoading} className="hover:scale-105 transition-transform" size="lg">
          {isLoading ? (
            <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2" />
          ) : (
            <Save className="w-4 h-4 mr-2" />
          )}
          {isLoading ? "Saving..." : "Save Profile"}
        </Button>
      </div>
    </form>
  )
}
