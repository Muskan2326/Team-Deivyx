"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { MessageCircle, Clock, Users, Heart } from "lucide-react"

interface Volunteer {
  id: string
  name: string
  specialties: string[]
  status: "online" | "busy" | "offline"
  responseTime: string
  rating: number
}

const volunteers: Volunteer[] = [
  {
    id: "1",
    name: "Sarah M.",
    specialties: ["Anxiety", "Depression", "Stress Management"],
    status: "online",
    responseTime: "Usually responds in 5 minutes",
    rating: 4.9,
  },
  {
    id: "2",
    name: "Alex K.",
    specialties: ["Grief", "Trauma", "Relationship Issues"],
    status: "online",
    responseTime: "Usually responds in 10 minutes",
    rating: 4.8,
  },
  {
    id: "3",
    name: "Jordan L.",
    specialties: ["LGBTQ+ Support", "Identity", "Self-Esteem"],
    status: "busy",
    responseTime: "Usually responds in 30 minutes",
    rating: 4.9,
  },
  {
    id: "4",
    name: "Morgan R.",
    specialties: ["Addiction Recovery", "Mindfulness", "Coping Skills"],
    status: "offline",
    responseTime: "Usually responds in 2 hours",
    rating: 4.7,
  },
]

export function VolunteerChat() {
  const [selectedVolunteer, setSelectedVolunteer] = useState<string | null>(null)

  const getStatusColor = (status: Volunteer["status"]) => {
    switch (status) {
      case "online":
        return "bg-green-500"
      case "busy":
        return "bg-yellow-500"
      case "offline":
        return "bg-gray-400"
    }
  }

  const getStatusText = (status: Volunteer["status"]) => {
    switch (status) {
      case "online":
        return "Available Now"
      case "busy":
        return "Busy"
      case "offline":
        return "Offline"
    }
  }

  const startChat = (volunteerId: string) => {
    setSelectedVolunteer(volunteerId)
    // In a real app, this would initiate a chat session
    console.log("Starting chat with volunteer:", volunteerId)
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-4">
        {volunteers.map((volunteer) => (
          <Card
            key={volunteer.id}
            className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02] cursor-pointer"
            onClick={() => startChat(volunteer.id)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-primary/20 text-primary font-semibold">
                        {volunteer.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${getStatusColor(
                        volunteer.status,
                      )}`}
                    />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{volunteer.name}</CardTitle>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge
                        variant="outline"
                        className={volunteer.status === "online" ? "border-green-200 text-green-800" : ""}
                      >
                        {getStatusText(volunteer.status)}
                      </Badge>
                      <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                        <Heart className="w-3 h-3 fill-current text-yellow-500" />
                        <span>{volunteer.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <Button
                  variant={volunteer.status === "online" ? "default" : "outline"}
                  size="sm"
                  className="hover:scale-105 transition-transform"
                  disabled={volunteer.status === "offline"}
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  {volunteer.status === "online" ? "Chat Now" : "Join Queue"}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex flex-wrap gap-1">
                  {volunteer.specialties.map((specialty) => (
                    <Badge key={specialty} variant="secondary" className="text-xs">
                      {specialty}
                    </Badge>
                  ))}
                </div>
                <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>{volunteer.responseTime}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5 text-primary" />
            <span>Group Support Sessions</span>
          </CardTitle>
          <CardDescription>Join scheduled group sessions for peer support and guided discussions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-background rounded-lg">
              <div>
                <h4 className="font-medium">Anxiety Support Circle</h4>
                <p className="text-sm text-muted-foreground">Today at 7:00 PM • 8 participants</p>
              </div>
              <Button size="sm" className="hover:scale-105 transition-transform">
                Join
              </Button>
            </div>
            <div className="flex items-center justify-between p-3 bg-background rounded-lg">
              <div>
                <h4 className="font-medium">Mindfulness & Meditation</h4>
                <p className="text-sm text-muted-foreground">Tomorrow at 6:00 AM • 12 participants</p>
              </div>
              <Button size="sm" variant="outline" className="hover:scale-105 transition-transform bg-transparent">
                Schedule
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
