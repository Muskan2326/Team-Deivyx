"use client"

import { useState, useMemo } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Video,
  Calendar,
  Clock,
  Star,
  MapPin,
  Search,
  Play,
  User,
  Phone,
  MessageCircle,
  Award,
  BookOpen,
} from "lucide-react"

interface Counselor {
  id: string
  name: string
  title: string
  specialties: string[]
  rating: number
  experience: string
  location: string
  languages: string[]
  availability: "available" | "busy" | "offline"
  nextSlot: string
  price: string
  videoUrl: string
  bio: string
  credentials: string[]
}

interface WellnessVideo {
  id: string
  title: string
  duration: string
  instructor: string
  thumbnail: string
  category: string
  description: string
  difficulty: "Beginner" | "Intermediate" | "Advanced"
}

const counselors: Counselor[] = [
  {
    id: "c1",
    name: "Dr. Sarah Chen",
    title: "Licensed Clinical Psychologist",
    specialties: ["Anxiety", "Depression", "CBT", "Mindfulness"],
    rating: 4.9,
    experience: "8 years",
    location: "California, USA",
    languages: ["English", "Mandarin"],
    availability: "available",
    nextSlot: "Today 2:00 PM",
    price: "$120/session",
    videoUrl: "https://meet.example.com/dr-sarah-chen",
    bio: "Specializing in cognitive behavioral therapy and mindfulness-based interventions for anxiety and depression.",
    credentials: ["PhD Psychology", "Licensed Clinical Psychologist", "CBT Certified"],
  },
  {
    id: "c2",
    name: "Dr. Michael Rodriguez",
    title: "Trauma Specialist",
    specialties: ["PTSD", "Trauma Recovery", "EMDR", "Grief Counseling"],
    rating: 4.8,
    experience: "12 years",
    location: "New York, USA",
    languages: ["English", "Spanish"],
    availability: "busy",
    nextSlot: "Tomorrow 10:00 AM",
    price: "$150/session",
    videoUrl: "https://meet.example.com/dr-michael-rodriguez",
    bio: "Expert in trauma-informed care with extensive experience in EMDR and grief counseling.",
    credentials: ["PhD Clinical Psychology", "EMDR Certified", "Trauma Specialist"],
  },
  {
    id: "c3",
    name: "Lisa Park, LMFT",
    title: "Marriage & Family Therapist",
    specialties: ["Couples Therapy", "Family Counseling", "Communication", "Relationship Issues"],
    rating: 4.7,
    experience: "6 years",
    location: "Texas, USA",
    languages: ["English", "Korean"],
    availability: "available",
    nextSlot: "Today 4:30 PM",
    price: "$100/session",
    videoUrl: "https://meet.example.com/lisa-park-lmft",
    bio: "Dedicated to helping couples and families build stronger, healthier relationships through evidence-based therapy.",
    credentials: ["LMFT Licensed", "Gottman Method Certified", "EFT Trained"],
  },
]

const wellnessVideos: WellnessVideo[] = [
  {
    id: "v1",
    title: "Morning Meditation for Anxiety",
    duration: "12:34",
    instructor: "Dr. Sarah Chen",
    thumbnail: "/peaceful-morning-meditation.png",
    category: "Meditation",
    description: "Start your day with calm and clarity through guided meditation techniques.",
    difficulty: "Beginner",
  },
  {
    id: "v2",
    title: "Breathing Techniques for Panic Attacks",
    duration: "8:45",
    instructor: "Dr. Michael Rodriguez",
    thumbnail: "/calming-breathing-exercise-visualization.jpg",
    category: "Breathing",
    description: "Learn effective breathing exercises to manage panic and anxiety symptoms.",
    difficulty: "Beginner",
  },
  {
    id: "v3",
    title: "Progressive Muscle Relaxation",
    duration: "15:20",
    instructor: "Lisa Park, LMFT",
    thumbnail: "/relaxation-therapy-session.jpg",
    category: "Relaxation",
    description: "Deep relaxation technique to release physical tension and mental stress.",
    difficulty: "Intermediate",
  },
  {
    id: "v4",
    title: "Mindful Communication Skills",
    duration: "18:45",
    instructor: "Dr. Sarah Chen",
    thumbnail: "/mindful-communication-session.jpg",
    category: "Communication",
    description: "Develop better listening and speaking skills for healthier relationships.",
    difficulty: "Intermediate",
  },
]

export function VideoCoaching() {
  const [searchTerm, setSearchTerm] = useState("")
  const [specialtyFilter, setSpecialtyFilter] = useState<string>("all")
  const [availabilityFilter, setAvailabilityFilter] = useState<string>("all")
  const [selectedCounselor, setSelectedCounselor] = useState<Counselor | null>(null)

  const filteredCounselors = useMemo(() => {
    return counselors.filter((counselor) => {
      const matchesSearch =
        counselor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        counselor.specialties.some((s) => s.toLowerCase().includes(searchTerm.toLowerCase()))
      const matchesSpecialty =
        specialtyFilter === "all" ||
        counselor.specialties.some((s) => s.toLowerCase().includes(specialtyFilter.toLowerCase()))
      const matchesAvailability = availabilityFilter === "all" || counselor.availability === availabilityFilter

      return matchesSearch && matchesSpecialty && matchesAvailability
    })
  }, [searchTerm, specialtyFilter, availabilityFilter])

  const getAvailabilityColor = (availability: string) => {
    switch (availability) {
      case "available":
        return "bg-green-500"
      case "busy":
        return "bg-yellow-500"
      case "offline":
        return "bg-gray-400"
      default:
        return "bg-gray-400"
    }
  }

  const getAvailabilityText = (availability: string) => {
    switch (availability) {
      case "available":
        return "Available Now"
      case "busy":
        return "Busy"
      case "offline":
        return "Offline"
      default:
        return "Unknown"
    }
  }

  const startVideoCall = (counselor: Counselor) => {
    // In a real app, this would open the video call interface
    window.open(counselor.videoUrl, "_blank")
    console.log("Starting video call with:", counselor.name)
  }

  return (
    <div className="space-y-6">
      {/* Search and Filter Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Video className="w-5 h-5 text-primary" />
            <span>Professional Video Coaching</span>
          </CardTitle>
          <CardDescription>Connect with licensed counselors and therapists via secure video sessions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search by name or specialty..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={specialtyFilter} onValueChange={setSpecialtyFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by specialty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Specialties</SelectItem>
                <SelectItem value="anxiety">Anxiety</SelectItem>
                <SelectItem value="depression">Depression</SelectItem>
                <SelectItem value="trauma">Trauma</SelectItem>
                <SelectItem value="couples">Couples Therapy</SelectItem>
              </SelectContent>
            </Select>
            <Select value={availabilityFilter} onValueChange={setAvailabilityFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Filter by availability" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Availability</SelectItem>
                <SelectItem value="available">Available Now</SelectItem>
                <SelectItem value="busy">Busy</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="counselors" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="counselors">Licensed Counselors</TabsTrigger>
          <TabsTrigger value="videos">Wellness Videos</TabsTrigger>
        </TabsList>

        <TabsContent value="counselors" className="space-y-4">
          <div className="grid gap-4">
            {filteredCounselors.map((counselor) => (
              <Card key={counselor.id} className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02]">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="relative">
                        <Avatar className="w-16 h-16">
                          <AvatarFallback className="bg-primary/20 text-primary font-semibold text-lg">
                            {counselor.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div
                          className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${getAvailabilityColor(counselor.availability)}`}
                        />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <CardTitle className="text-xl">{counselor.name}</CardTitle>
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 fill-current text-yellow-500" />
                            <span className="font-medium">{counselor.rating}</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground font-medium">{counselor.title}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <Badge
                            variant="outline"
                            className={counselor.availability === "available" ? "border-green-200 text-green-800" : ""}
                          >
                            {getAvailabilityText(counselor.availability)}
                          </Badge>
                          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                            <MapPin className="w-3 h-3" />
                            <span>{counselor.location}</span>
                          </div>
                          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                            <Award className="w-3 h-3" />
                            <span>{counselor.experience} experience</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            className="hover:scale-105 transition-transform bg-transparent"
                          >
                            <User className="w-4 h-4 mr-2" />
                            View Profile
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle className="flex items-center space-x-2">
                              <Avatar className="w-12 h-12">
                                <AvatarFallback className="bg-primary/20 text-primary font-semibold">
                                  {counselor.name
                                    .split(" ")
                                    .map((n) => n[0])
                                    .join("")}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div>{counselor.name}</div>
                                <div className="text-sm text-muted-foreground font-normal">{counselor.title}</div>
                              </div>
                            </DialogTitle>
                            <DialogDescription className="space-y-4">
                              <p>{counselor.bio}</p>
                              <div>
                                <h4 className="font-semibold mb-2">Credentials:</h4>
                                <div className="flex flex-wrap gap-2">
                                  {counselor.credentials.map((cred) => (
                                    <Badge key={cred} variant="secondary">
                                      {cred}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                              <div>
                                <h4 className="font-semibold mb-2">Languages:</h4>
                                <p>{counselor.languages.join(", ")}</p>
                              </div>
                              <div className="flex items-center justify-between pt-4 border-t">
                                <div>
                                  <p className="font-semibold">{counselor.price}</p>
                                  <p className="text-sm text-muted-foreground">Next available: {counselor.nextSlot}</p>
                                </div>
                                <Button
                                  onClick={() => startVideoCall(counselor)}
                                  className="hover:scale-105 transition-transform"
                                >
                                  <Video className="w-4 h-4 mr-2" />
                                  Start Video Call
                                </Button>
                              </div>
                            </DialogDescription>
                          </DialogHeader>
                        </DialogContent>
                      </Dialog>
                      <Button
                        onClick={() => startVideoCall(counselor)}
                        disabled={counselor.availability === "offline"}
                        className="hover:scale-105 transition-transform"
                        size="sm"
                      >
                        <Video className="w-4 h-4 mr-2" />
                        {counselor.availability === "available" ? "Start Call" : "Schedule"}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-1">
                      {counselor.specialties.map((specialty) => (
                        <Badge key={specialty} variant="secondary" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-3 h-3" />
                        <span>Next slot: {counselor.nextSlot}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-3 h-3" />
                        <span>{counselor.price}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="videos" className="space-y-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {wellnessVideos.map((video) => (
              <Card
                key={video.id}
                className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02] cursor-pointer"
              >
                <div className="relative overflow-hidden rounded-t-lg">
                  <img
                    src={video.thumbnail || "/placeholder.svg?height=200&width=300&query=wellness video thumbnail"}
                    alt={video.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/20 hover:bg-black/10 transition-colors flex items-center justify-center">
                    <Button size="lg" className="bg-white/90 hover:bg-white text-slate-800 rounded-full h-16 w-16 p-0">
                      <Play className="h-6 w-6 ml-1" />
                    </Button>
                  </div>
                  <div className="absolute top-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm">
                    {video.duration}
                  </div>
                  <div className="absolute top-2 left-2">
                    <Badge variant="secondary" className="bg-white/90 text-slate-800">
                      {video.difficulty}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="mb-2">
                    <Badge variant="outline" className="text-xs">
                      {video.category}
                    </Badge>
                  </div>
                  <h3 className="font-semibold text-slate-800 mb-2 line-clamp-2">{video.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{video.description}</p>
                  <div className="flex items-center justify-between text-sm text-slate-500">
                    <div className="flex items-center gap-1">
                      <User className="h-4 w-4" />
                      {video.instructor}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {video.duration}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Emergency Support */}
      <Card className="bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-red-800">
            <Phone className="w-5 h-5" />
            <span>Crisis Support</span>
          </CardTitle>
          <CardDescription className="text-red-700">
            If you're experiencing a mental health emergency, immediate help is available
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button variant="destructive" className="hover:scale-105 transition-transform">
              <Phone className="w-4 h-4 mr-2" />
              Call Crisis Hotline
            </Button>
            <Button variant="outline" className="border-red-300 text-red-700 hover:bg-red-50 bg-white">
              <MessageCircle className="w-4 h-4 mr-2" />
              Crisis Text Line
            </Button>
            <Button variant="outline" className="border-red-300 text-red-700 hover:bg-red-50 bg-white">
              <BookOpen className="w-4 h-4 mr-2" />
              Emergency Resources
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
