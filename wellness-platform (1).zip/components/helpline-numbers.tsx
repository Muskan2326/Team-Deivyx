import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Phone, Clock, Globe, MessageCircle } from "lucide-react"

const helplines = [
  {
    name: "National Suicide Prevention Lifeline",
    number: "988",
    description: "24/7 crisis support for suicidal thoughts and mental health emergencies",
    availability: "24/7",
    methods: ["Phone", "Chat", "Text"],
    priority: "high",
  },
  {
    name: "Crisis Text Line",
    number: "Text HOME to 741741",
    description: "Free, confidential crisis support via text message",
    availability: "24/7",
    methods: ["Text"],
    priority: "high",
  },
  {
    name: "NAMI Helpline",
    number: "1-800-950-6264",
    description: "Information, referrals, and support for mental health conditions",
    availability: "Mon-Fri 10am-10pm ET",
    methods: ["Phone", "Email"],
    priority: "medium",
  },
  {
    name: "SAMHSA National Helpline",
    number: "1-800-662-4357",
    description: "Treatment referral service for substance abuse and mental health",
    availability: "24/7",
    methods: ["Phone"],
    priority: "medium",
  },
  {
    name: "LGBT National Hotline",
    number: "1-888-843-4564",
    description: "Peer support and local resources for LGBTQ+ community",
    availability: "Mon-Fri 4pm-12am, Sat 12pm-5pm ET",
    methods: ["Phone", "Chat"],
    priority: "medium",
  },
]

export function HelplinNumbers() {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 border-red-200"
      case "medium":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
        <h3 className="font-semibold text-red-800 mb-2">Emergency Notice</h3>
        <p className="text-red-700 text-sm">
          If you're having thoughts of suicide or are in immediate danger, please call 988 or go to your nearest
          emergency room. You are not alone, and help is available.
        </p>
      </div>

      {helplines.map((helpline, index) => (
        <Card
          key={index}
          className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02] animate-slide-in"
          style={{ animationDelay: `${index * 0.1}s` }}
        >
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <CardTitle className="text-lg">{helpline.name}</CardTitle>
                  {helpline.priority === "high" && (
                    <Badge className={getPriorityColor(helpline.priority)}>Emergency</Badge>
                  )}
                </div>
                <CardDescription>{helpline.description}</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4 text-primary" />
                <span className="font-mono font-semibold text-lg">{helpline.number}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Clock className="w-3 h-3" />
                <span>{helpline.availability}</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex flex-wrap gap-1">
                {helpline.methods.map((method) => (
                  <Badge key={method} variant="outline" className="text-xs">
                    {method === "Phone" && <Phone className="w-3 h-3 mr-1" />}
                    {method === "Chat" && <MessageCircle className="w-3 h-3 mr-1" />}
                    {method === "Text" && <MessageCircle className="w-3 h-3 mr-1" />}
                    {method === "Email" && <Globe className="w-3 h-3 mr-1" />}
                    {method}
                  </Badge>
                ))}
              </div>

              <div className="flex space-x-2">
                {helpline.methods.includes("Phone") && (
                  <Button size="sm" className="hover:scale-105 transition-transform">
                    <Phone className="w-3 h-3 mr-1" />
                    Call
                  </Button>
                )}
                {helpline.methods.includes("Chat") && (
                  <Button size="sm" variant="outline" className="hover:scale-105 transition-transform bg-transparent">
                    <MessageCircle className="w-3 h-3 mr-1" />
                    Chat
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
