"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, Sparkles, Smile, Eye } from "lucide-react"

interface AvatarState {
  isBlinking: boolean
  isSmiling: boolean
  isHappy: boolean
  clickCount: number
  lastInteraction: Date | null
}

export function InteractiveAvatar() {
  const [avatarState, setAvatarState] = useState<AvatarState>({
    isBlinking: false,
    isSmiling: false,
    isHappy: false,
    clickCount: 0,
    lastInteraction: null,
  })

  const avatarRef = useRef<HTMLDivElement>(null)
  const blinkIntervalRef = useRef<NodeJS.Timeout>()

  // Auto-blink every 3-5 seconds
  useEffect(() => {
    const startBlinking = () => {
      blinkIntervalRef.current = setInterval(
        () => {
          if (!avatarState.isBlinking) {
            triggerBlink()
          }
        },
        3000 + Math.random() * 2000,
      )
    }

    startBlinking()
    return () => {
      if (blinkIntervalRef.current) {
        clearInterval(blinkIntervalRef.current)
      }
    }
  }, [avatarState.isBlinking])

  const triggerBlink = () => {
    setAvatarState((prev) => ({ ...prev, isBlinking: true }))
    setTimeout(() => {
      setAvatarState((prev) => ({ ...prev, isBlinking: false }))
    }, 150)
  }

  const triggerSmile = () => {
    setAvatarState((prev) => ({
      ...prev,
      isSmiling: true,
      isHappy: true,
      clickCount: prev.clickCount + 1,
      lastInteraction: new Date(),
    }))

    // Smile duration based on interaction frequency
    const smileDuration = Math.min(2000 + avatarState.clickCount * 500, 5000)

    setTimeout(() => {
      setAvatarState((prev) => ({ ...prev, isSmiling: false }))
    }, smileDuration)

    setTimeout(() => {
      setAvatarState((prev) => ({ ...prev, isHappy: false }))
    }, smileDuration + 1000)
  }

  const handleAvatarClick = () => {
    // Trigger both blink and smile on click
    triggerBlink()
    setTimeout(() => triggerSmile(), 200)

    // Add bounce animation
    if (avatarRef.current) {
      avatarRef.current.style.transform = "scale(1.1)"
      setTimeout(() => {
        if (avatarRef.current) {
          avatarRef.current.style.transform = "scale(1)"
        }
      }, 200)
    }
  }

  const getAvatarMood = () => {
    if (avatarState.isHappy) return "Very Happy! 😊"
    if (avatarState.clickCount > 5) return "Excited! ✨"
    if (avatarState.clickCount > 2) return "Happy 😊"
    if (avatarState.lastInteraction) return "Content 😌"
    return "Waiting for interaction..."
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardContent className="p-6 text-center">
        <div className="space-y-4">
          {/* Interactive Avatar */}
          <div
            ref={avatarRef}
            onClick={handleAvatarClick}
            className="relative w-32 h-32 mx-auto cursor-pointer transition-all duration-300 hover:scale-105"
          >
            {/* Avatar Face */}
            <div className="w-full h-full bg-gradient-to-br from-purple-200 to-pink-200 rounded-full border-4 border-purple-300 shadow-lg flex items-center justify-center relative overflow-hidden">
              {/* Eyes */}
              <div className="absolute top-8 left-8 right-8 flex justify-between">
                <div
                  className={`w-4 h-4 bg-purple-800 rounded-full transition-all duration-150 ${
                    avatarState.isBlinking ? "h-1" : "h-4"
                  }`}
                />
                <div
                  className={`w-4 h-4 bg-purple-800 rounded-full transition-all duration-150 ${
                    avatarState.isBlinking ? "h-1" : "h-4"
                  }`}
                />
              </div>

              {/* Mouth */}
              <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2">
                {avatarState.isSmiling ? (
                  <div className="w-8 h-4 border-b-4 border-purple-800 rounded-full" />
                ) : (
                  <div className="w-4 h-1 bg-purple-800 rounded-full" />
                )}
              </div>

              {/* Happy particles */}
              {avatarState.isHappy && (
                <>
                  <Heart className="absolute top-2 right-2 w-4 h-4 text-pink-500 animate-bounce" />
                  <Sparkles className="absolute top-2 left-2 w-4 h-4 text-yellow-500 animate-pulse" />
                  <Heart className="absolute bottom-2 left-4 w-3 h-3 text-red-500 animate-ping" />
                </>
              )}
            </div>

            {/* Click ripple effect */}
            <div
              className="absolute inset-0 rounded-full border-2 border-purple-400 animate-ping opacity-0 pointer-events-none"
              style={{
                animation: avatarState.lastInteraction ? "ping 1s cubic-bezier(0, 0, 0.2, 1)" : "none",
              }}
            />
          </div>

          {/* Avatar Status */}
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-purple-800">Your AI Companion</h3>
            <p className="text-sm text-purple-600">{getAvatarMood()}</p>
            <p className="text-xs text-muted-foreground">Clicks: {avatarState.clickCount} • Click me to interact!</p>
          </div>

          {/* Quick Actions */}
          <div className="flex justify-center space-x-2">
            <Button
              size="sm"
              variant="outline"
              onClick={triggerBlink}
              className="hover:scale-105 transition-transform bg-transparent"
            >
              <Eye className="w-3 h-3 mr-1" />
              Blink
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={triggerSmile}
              className="hover:scale-105 transition-transform bg-transparent"
            >
              <Smile className="w-3 h-3 mr-1" />
              Smile
            </Button>
          </div>

          {/* Interaction Tips */}
          <div className="bg-purple-50 rounded-lg p-3 text-xs text-purple-700">
            <p>
              💡 <strong>Tip:</strong> The more you interact, the happier I become!
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
