"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Home, User, Users, ClipboardList, BarChart3, HelpCircle, Menu, X, Heart } from "lucide-react"
import { cn } from "@/lib/utils"

const navigationItems = [
  { href: "/profile", label: "Profile", icon: User },
  { href: "/", label: "Home", icon: Home },
  { href: "/help", label: "Help", icon: HelpCircle },
  { href: "/community", label: "Community", icon: Users },
  { href: "/dashboard", label: "Dashboard", icon: BarChart3 },
  { href: "/surveys", label: "Survey", icon: ClipboardList },
]

export function Navigation() {
  const pathname = usePathname()
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="hidden md:flex fixed top-0 left-0 right-0 z-50 bg-purple-100/90 backdrop-blur-md border-b border-purple-200">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Heart className="w-6 h-6 text-purple-600" />
              <h1 className="text-xl font-semibold text-purple-800">MindHeart</h1>
            </div>

            <div className="flex items-center space-x-8">
              {navigationItems.map((item) => {
                const Icon = item.icon
                const isActive = pathname === item.href
                return (
                  <Link key={item.href} href={item.href}>
                    <span
                      className={cn(
                        "text-sm font-medium transition-colors hover:text-purple-700",
                        isActive ? "text-purple-800 font-semibold" : "text-purple-600",
                      )}
                    >
                      {item.label}
                    </span>
                  </Link>
                )
              })}
            </div>

            <Button
              variant="outline"
              size="sm"
              className="border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
            >
              Sign In
            </Button>
          </div>
        </div>
      </nav>

      {/* Mobile Navigation */}
      <nav className="md:hidden fixed top-0 left-0 right-0 z-50 bg-purple-100/90 backdrop-blur-md border-b border-purple-200">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Heart className="w-5 h-5 text-purple-600" />
              <h1 className="text-lg font-semibold text-purple-800">MindHeart</h1>
            </div>

            <Button variant="ghost" size="sm" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2">
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu Overlay */}
        {isMobileMenuOpen && (
          <div className="absolute top-full left-0 right-0 bg-purple-100/95 backdrop-blur-md border-b border-purple-200 animate-slide-in">
            <div className="container mx-auto px-4 py-4">
              <div className="grid grid-cols-2 gap-2">
                {navigationItems.map((item) => {
                  const Icon = item.icon
                  const isActive = pathname === item.href
                  return (
                    <Link key={item.href} href={item.href} onClick={() => setIsMobileMenuOpen(false)}>
                      <Card
                        className={cn(
                          "p-3 hover:shadow-md transition-all duration-200 hover:scale-105 cursor-pointer",
                          isActive && "bg-purple-200 text-purple-800",
                        )}
                      >
                        <div className="flex items-center space-x-2">
                          <Icon className="w-4 h-4" />
                          <span className="text-sm font-medium">{item.label}</span>
                        </div>
                      </Card>
                    </Link>
                  )
                })}
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Spacer for fixed navigation */}
      <div className="h-16" />
    </>
  )
}
