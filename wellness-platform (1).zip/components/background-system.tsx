"use client"

import { usePathname } from "next/navigation"
import { useEffect, useState } from "react"

const backgroundMap = {
  "/": "/backgrounds/homepage-sunset-beach.jpg",
  "/dashboard": "/backgrounds/dashboard-forest-mist.jpg",
  "/community": "/backgrounds/community-meadow.jpg",
  "/profile": "/backgrounds/profile-mountain-lake.jpg",
  "/help": "/backgrounds/help-aurora.jpg",
  "/support": "/backgrounds/help-aurora.jpg",
  "/about": "/backgrounds/community-meadow.jpg",
  "/contact": "/backgrounds/profile-mountain-lake.jpg",
}

export function BackgroundSystem() {
  const pathname = usePathname()
  const [currentBg, setCurrentBg] = useState("/backgrounds/homepage-sunset-beach.jpg")

  useEffect(() => {
    const bg = backgroundMap[pathname as keyof typeof backgroundMap] || backgroundMap["/"]
    setCurrentBg(bg)
  }, [pathname])

  return (
    <>
      <div
        className="fixed inset-0 bg-cover bg-center bg-no-repeat transition-all duration-1000 ease-in-out"
        style={{ backgroundImage: `url(${currentBg})` }}
      />

      <div className="fixed inset-0 bg-gradient-to-b from-white/20 via-purple-500/10 to-pink-500/20" />

      <div className="fixed inset-0 bg-gradient-to-br from-transparent via-purple-400/5 to-orange-400/10" />
    </>
  )
}
