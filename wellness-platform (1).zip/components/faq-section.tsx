"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"

const faqs = [
  {
    question: "How do I know if I need professional help?",
    answer:
      "Consider seeking professional help if you're experiencing persistent sadness, anxiety, or other symptoms that interfere with daily life for more than two weeks. Signs include changes in sleep, appetite, energy levels, or thoughts of self-harm. Trust your instincts - if you feel you need help, it's worth reaching out.",
  },
  {
    question: "Is my information kept confidential on this platform?",
    answer:
      "Yes, we take your privacy seriously. All conversations with volunteers are confidential, and your personal information is protected. We only share information if there's an immediate risk of harm to yourself or others, and we'll always try to discuss this with you first.",
  },
  {
    question: "What's the difference between anxiety and stress?",
    answer:
      "Stress is typically a response to external pressures and usually subsides when the stressor is removed. Anxiety can persist even without clear triggers and may involve excessive worry about future events. Both are normal human experiences, but if they significantly impact your daily life, consider speaking with a mental health professional.",
  },
  {
    question: "How can I support a friend who's struggling?",
    answer:
      "Listen without judgment, validate their feelings, and encourage them to seek professional help if needed. Avoid trying to 'fix' their problems or offering unsolicited advice. Sometimes just being present and showing you care makes a huge difference. Take care of your own mental health too.",
  },
  {
    question: "What are some daily practices for better mental health?",
    answer:
      "Regular exercise, adequate sleep (7-9 hours), mindfulness or meditation, connecting with others, limiting social media, spending time in nature, and maintaining a routine can all support mental wellness. Start small - even 5 minutes of deep breathing can help.",
  },
  {
    question: "How do I find a therapist that's right for me?",
    answer:
      "Consider factors like their specialties, approach (CBT, DBT, etc.), location, insurance coverage, and whether you feel comfortable with them. Many therapists offer brief consultations. It's okay to try a few different therapists to find the right fit - the therapeutic relationship is crucial for success.",
  },
  {
    question: "What should I do during a panic attack?",
    answer:
      "Try the 5-4-3-2-1 grounding technique: identify 5 things you can see, 4 you can touch, 3 you can hear, 2 you can smell, and 1 you can taste. Practice slow, deep breathing. Remind yourself that panic attacks are temporary and will pass. If they're frequent, consider speaking with a healthcare provider.",
  },
  {
    question: "Is medication always necessary for mental health conditions?",
    answer:
      "Not always. Treatment varies by individual and condition. Some people benefit from therapy alone, others from medication, and many from a combination. Work with a healthcare provider to determine what's best for you. Never stop prescribed medication without consulting your doctor first.",
  },
]

export function FAQSection() {
  const [openItems, setOpenItems] = useState<number[]>([])

  const toggleItem = (index: number) => {
    setOpenItems((prev) => (prev.includes(index) ? prev.filter((item) => item !== index) : [...prev, index]))
  }

  return (
    <div className="space-y-3">
      {faqs.map((faq, index) => (
        <Card
          key={index}
          className="hover:shadow-md transition-all duration-200 animate-slide-in"
          style={{ animationDelay: `${index * 0.05}s` }}
        >
          <CardContent className="p-0">
            <Button
              variant="ghost"
              onClick={() => toggleItem(index)}
              className="w-full justify-between p-4 h-auto text-left hover:bg-muted/50"
            >
              <span className="font-medium text-foreground pr-4">{faq.question}</span>
              {openItems.includes(index) ? (
                <ChevronUp className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              ) : (
                <ChevronDown className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              )}
            </Button>
            <div
              className={cn(
                "overflow-hidden transition-all duration-200",
                openItems.includes(index) ? "max-h-96 opacity-100" : "max-h-0 opacity-0",
              )}
            >
              <div className="p-4 pt-0 text-muted-foreground leading-relaxed">{faq.answer}</div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
