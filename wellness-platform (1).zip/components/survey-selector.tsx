"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { PHQ9Survey } from "@/components/surveys/phq9-survey"
import { GAD7Survey } from "@/components/surveys/gad7-survey"
import { GHQSurvey } from "@/components/surveys/ghq-survey"
import { FoodSurvey } from "@/components/surveys/food-survey"
import { Brain, Heart, ClipboardList, Utensils, Clock, ArrowLeft } from "lucide-react"

type SurveyType = "phq9" | "gad7" | "ghq" | "food" | null

const surveys = [
  {
    id: "phq9" as SurveyType,
    title: "PHQ-9 Depression Assessment",
    description: "A 9-question screening tool for depression symptoms over the past two weeks",
    icon: Brain,
    duration: "5-7 minutes",
    questions: 9,
    color: "bg-blue-100 text-blue-800 border-blue-200",
  },
  {
    id: "gad7" as SurveyType,
    title: "GAD-7 Anxiety Assessment",
    description: "A 7-question tool to measure anxiety symptoms and their severity",
    icon: Heart,
    duration: "3-5 minutes",
    questions: 7,
    color: "bg-green-100 text-green-800 border-green-200",
  },
  {
    id: "ghq" as SurveyType,
    title: "General Health Questionnaire",
    description: "A comprehensive assessment of psychological well-being and distress",
    icon: ClipboardList,
    duration: "8-10 minutes",
    questions: 12,
    color: "bg-purple-100 text-purple-800 border-purple-200",
  },
  {
    id: "food" as SurveyType,
    title: "Nutrition & Eating Habits Survey",
    description: "Assess your relationship with food and eating patterns",
    icon: Utensils,
    duration: "6-8 minutes",
    questions: 15,
    color: "bg-orange-100 text-orange-800 border-orange-200",
  },
]

export function SurveySelector() {
  const [selectedSurvey, setSelectedSurvey] = useState<SurveyType>(null)

  const renderSurvey = () => {
    switch (selectedSurvey) {
      case "phq9":
        return <PHQ9Survey onComplete={() => setSelectedSurvey(null)} />
      case "gad7":
        return <GAD7Survey onComplete={() => setSelectedSurvey(null)} />
      case "ghq":
        return <GHQSurvey onComplete={() => setSelectedSurvey(null)} />
      case "food":
        return <FoodSurvey onComplete={() => setSelectedSurvey(null)} />
      default:
        return null
    }
  }

  if (selectedSurvey) {
    return (
      <div className="space-y-6">
        <Button
          variant="outline"
          onClick={() => setSelectedSurvey(null)}
          className="hover:scale-105 transition-transform bg-transparent"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Survey Selection
        </Button>
        {renderSurvey()}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-semibold text-foreground mb-4">Choose an Assessment</h2>
        <p className="text-muted-foreground">
          Select a survey to begin. All responses are confidential and help create your personalized wellness insights.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {surveys.map((survey, index) => {
          const Icon = survey.icon
          return (
            <Card
              key={survey.id}
              className="hover:shadow-lg transition-all duration-200 hover:scale-105 cursor-pointer animate-slide-in"
              style={{ animationDelay: `${index * 0.1}s` }}
              onClick={() => setSelectedSurvey(survey.id)}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{survey.title}</CardTitle>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" className={survey.color}>
                          {survey.questions} questions
                        </Badge>
                        <div className="flex items-center space-x-1 text-sm text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          <span>{survey.duration}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="mb-4">{survey.description}</CardDescription>
                <Button className="w-full hover:scale-105 transition-transform">Start Assessment</Button>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
        <CardHeader>
          <CardTitle>Important Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm text-muted-foreground">
          <p>• These assessments are screening tools and not diagnostic instruments</p>
          <p>• Results should be discussed with a healthcare professional</p>
          <p>• Your responses are confidential and stored securely</p>
          <p>• You can retake assessments to track changes over time</p>
        </CardContent>
      </Card>
    </div>
  )
}
