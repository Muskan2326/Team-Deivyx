"use client"

import { useEffect, useState } from "react"

interface FloatingElement {
  id: number
  x: number
  y: number
  size: number
  speedX: number
  speedY: number
  opacity: number
  type: "heart" | "star" | "circle"
}

export function BackgroundAnimation() {
  const [elements, setElements] = useState<FloatingElement[]>([])

  useEffect(() => {
    const newElements: FloatingElement[] = []

    for (let i = 0; i < 12; i++) {
      newElements.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 20 + 10,
        speedX: (Math.random() - 0.5) * 0.3,
        speedY: (Math.random() - 0.5) * 0.3,
        opacity: Math.random() * 0.2 + 0.1,
        type: "circle", // Only use circles to avoid emoji contrast issues
      })
    }
    setElements(newElements)

    // Animate floating elements
    const interval = setInterval(() => {
      setElements((prev) =>
        prev.map((element) => ({
          ...element,
          x: (element.x + element.speedX + 100) % 100,
          y: (element.y + element.speedY + 100) % 100,
        })),
      )
    }, 100)

    return () => clearInterval(interval)
  }, [])

  const renderElement = (element: FloatingElement) => {
    const baseStyle = {
      left: `${element.x}%`,
      top: `${element.y}%`,
      opacity: element.opacity,
      transform: "translate(-50%, -50%)",
    }

    return (
      <div
        key={element.id}
        className="absolute rounded-full bg-white/30 animate-gentle-pulse pointer-events-none"
        style={{
          ...baseStyle,
          width: `${element.size}px`,
          height: `${element.size}px`,
        }}
      />
    )
  }

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      <div
        className="absolute inset-0 bg-gradient-to-b from-purple-500/10 via-pink-400/5 to-orange-300/10 animate-pulse"
        style={{ animationDuration: "4s" }}
      />

      {elements.map(renderElement)}

      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute top-10 left-0 w-32 h-16 bg-white/30 rounded-full animate-float"
          style={{ animationDelay: "0s", animationDuration: "8s" }}
        />
        <div
          className="absolute top-20 right-20 w-24 h-12 bg-white/20 rounded-full animate-float"
          style={{ animationDelay: "2s", animationDuration: "10s" }}
        />
        <div
          className="absolute top-32 left-1/3 w-28 h-14 bg-white/25 rounded-full animate-float"
          style={{ animationDelay: "4s", animationDuration: "12s" }}
        />
      </div>
    </div>
  )
}
