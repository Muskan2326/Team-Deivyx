"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Heart, MessageCircle, Share2, MoreHorizontal, User } from "lucide-react"
import { cn } from "@/lib/utils"

interface Post {
  id: string
  author: string
  nickname: string
  content: string
  timestamp: Date
  likes: number
  comments: number
  isLiked: boolean
  mood: "positive" | "neutral" | "support"
}

const samplePosts: Post[] = [
  {
    id: "1",
    author: "user123",
    nickname: "SunnyDays",
    content:
      "Had a really good therapy session today. Sometimes it's hard to open up, but I'm learning that vulnerability is actually a strength. Grateful for this community! 💙",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    likes: 24,
    comments: 8,
    isLiked: false,
    mood: "positive",
  },
  {
    id: "2",
    author: "user456",
    nickname: "QuietStrength",
    content:
      "Struggling with anxiety today. The breathing exercises from yesterday's session are helping a bit. One breath at a time. 🌸",
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
    likes: 31,
    comments: 12,
    isLiked: true,
    mood: "support",
  },
  {
    id: "3",
    author: "user789",
    nickname: "MindfulMoments",
    content:
      "Week 3 of my mindfulness journey. Started with just 5 minutes of meditation, now up to 15! Small steps lead to big changes. What's your favorite mindfulness practice?",
    timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
    likes: 18,
    comments: 15,
    isLiked: false,
    mood: "positive",
  },
  {
    id: "4",
    author: "user321",
    nickname: "HealingHeart",
    content:
      "Some days are harder than others, and that's okay. Reminding myself that healing isn't linear. Sending love to anyone who needs it today. ❤️",
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000),
    likes: 42,
    comments: 6,
    isLiked: true,
    mood: "support",
  },
]

export function CommunityFeed() {
  const [posts, setPosts] = useState<Post[]>(samplePosts)
  const [isLoading, setIsLoading] = useState(false)

  const handleLike = (postId: string) => {
    setPosts((prev) =>
      prev.map((post) =>
        post.id === postId
          ? {
              ...post,
              isLiked: !post.isLiked,
              likes: post.isLiked ? post.likes - 1 : post.likes + 1,
            }
          : post,
      ),
    )
  }

  const getMoodColor = (mood: Post["mood"]) => {
    switch (mood) {
      case "positive":
        return "bg-green-100 text-green-800 border-green-200"
      case "support":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "neutral":
        return "bg-gray-100 text-gray-800 border-gray-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getMoodLabel = (mood: Post["mood"]) => {
    switch (mood) {
      case "positive":
        return "Celebrating"
      case "support":
        return "Seeking Support"
      case "neutral":
        return "Sharing"
      default:
        return "Sharing"
    }
  }

  const formatTimeAgo = (date: Date) => {
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) return "Just now"
    if (diffInHours === 1) return "1 hour ago"
    if (diffInHours < 24) return `${diffInHours} hours ago`
    return date.toLocaleDateString()
  }

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Randomly update like counts to simulate real-time activity
      setPosts((prev) =>
        prev.map((post) => ({
          ...post,
          likes: Math.random() > 0.95 ? post.likes + 1 : post.likes,
        })),
      )
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold text-foreground">Community Feed</h2>
        <Button
          variant="outline"
          onClick={() => {
            setIsLoading(true)
            setTimeout(() => setIsLoading(false), 1000)
          }}
          disabled={isLoading}
          className="hover:scale-105 transition-transform bg-transparent"
        >
          {isLoading ? "Refreshing..." : "Refresh Feed"}
        </Button>
      </div>

      <div className="space-y-4">
        {posts.map((post, index) => (
          <Card
            key={post.id}
            className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02] animate-slide-in"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="bg-primary/20">
                      <User className="w-5 h-5" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="font-semibold text-foreground">{post.nickname}</h3>
                      <Badge variant="outline" className={cn("text-xs", getMoodColor(post.mood))}>
                        {getMoodLabel(post.mood)}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{formatTimeAgo(post.timestamp)}</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" className="hover:scale-105 transition-transform">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <p className="text-foreground leading-relaxed">{post.content}</p>

              <div className="flex items-center justify-between pt-2 border-t border-border">
                <div className="flex items-center space-x-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleLike(post.id)}
                    className={cn(
                      "flex items-center space-x-2 hover:scale-105 transition-all",
                      post.isLiked && "text-red-500",
                    )}
                  >
                    <Heart className={cn("w-4 h-4", post.isLiked && "fill-current")} />
                    <span>{post.likes}</span>
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center space-x-2 hover:scale-105 transition-transform"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>{post.comments}</span>
                  </Button>

                  <Button variant="ghost" size="sm" className="hover:scale-105 transition-transform">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>

                <Button variant="outline" size="sm" className="hover:scale-105 transition-transform bg-transparent">
                  Support
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Load More */}
      <div className="text-center">
        <Button
          variant="outline"
          onClick={() => {
            setIsLoading(true)
            setTimeout(() => setIsLoading(false), 1000)
          }}
          disabled={isLoading}
          className="hover:scale-105 transition-transform bg-transparent"
        >
          {isLoading ? "Loading..." : "Load More Posts"}
        </Button>
      </div>
    </div>
  )
}
