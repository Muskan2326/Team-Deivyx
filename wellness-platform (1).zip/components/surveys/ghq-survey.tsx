"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CheckCircle, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface GHQSurveyProps {
  onComplete: () => void
}

const questions = [
  "Been able to concentrate on whatever you're doing?",
  "Lost much sleep over worry?",
  "Felt that you were playing a useful part in things?",
  "Felt capable of making decisions about things?",
  "Felt constantly under strain?",
  "Felt you couldn't overcome your difficulties?",
  "Been able to enjoy your normal day-to-day activities?",
  "Been able to face up to problems?",
  "Been feeling unhappy or depressed?",
  "Been losing confidence in yourself?",
  "Been thinking of yourself as a worthless person?",
  "Been feeling reasonably happy, all things considered?",
]

const options = [
  { value: "0", label: "Better than usual", score: 0 },
  { value: "1", label: "Same as usual", score: 0 },
  { value: "2", label: "Less than usual", score: 1 },
  { value: "3", label: "Much less than usual", score: 1 },
]

const reverseScoreQuestions = [1, 4, 5, 8, 9, 10] // 0-indexed

export function GHQSurvey({ onComplete }: GHQSurveyProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [isCompleted, setIsCompleted] = useState(false)
  const [hasError, setHasError] = useState(false)

  const progress = ((currentQuestion + 1) / questions.length) * 100

  const handleAnswer = (value: string) => {
    setAnswers({ ...answers, [currentQuestion]: value })
    setHasError(false)
  }

  const handleNext = () => {
    if (!answers[currentQuestion]) {
      setHasError(true)
      return
    }

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setIsCompleted(true)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      setHasError(false)
    }
  }

  const calculateScore = () => {
    return Object.entries(answers).reduce((total, [questionIndex, answer]) => {
      const qIndex = Number.parseInt(questionIndex)
      const option = options.find((opt) => opt.value === answer)
      let score = option?.score || 0

      // Reverse scoring for certain questions
      if (reverseScoreQuestions.includes(qIndex)) {
        score = score === 0 ? 1 : 0
      }

      return total + score
    }, 0)
  }

  const getScoreInterpretation = (score: number) => {
    if (score <= 2) return { level: "Low", color: "text-green-600", description: "Low psychological distress" }
    if (score <= 4)
      return { level: "Moderate", color: "text-yellow-600", description: "Moderate psychological distress" }
    return { level: "High", color: "text-red-600", description: "High psychological distress" }
  }

  if (isCompleted) {
    const score = calculateScore()
    const interpretation = getScoreInterpretation(score)

    return (
      <Card className="max-w-2xl mx-auto animate-slide-in">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl">GHQ Assessment Complete</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-foreground mb-2">{score}/12</div>
            <div className={cn("text-lg font-semibold", interpretation.color)}>{interpretation.level}</div>
            <p className="text-muted-foreground mt-2">{interpretation.description}</p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-semibold text-blue-800 mb-2">Understanding Your Results</h4>
            <p className="text-blue-700 text-sm">
              The GHQ measures psychological well-being and distress. Higher scores may indicate the need for additional
              support or professional consultation.
            </p>
          </div>

          <div className="flex space-x-4">
            <Button
              onClick={onComplete}
              variant="outline"
              className="flex-1 hover:scale-105 transition-transform bg-transparent"
            >
              Take Another Survey
            </Button>
            <Button className="flex-1 hover:scale-105 transition-transform">View Dashboard</Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between mb-4">
          <CardTitle className="text-xl">General Health Questionnaire</CardTitle>
          <div className="text-sm text-muted-foreground">
            {currentQuestion + 1} of {questions.length}
          </div>
        </div>
        <Progress value={progress} className="w-full" />
      </CardHeader>
      <CardContent className="space-y-6">
        <div className={cn("transition-all duration-300", hasError && "animate-shake")}>
          <h3 className="text-lg font-medium text-foreground mb-4">Have you recently:</h3>
          <p className="text-foreground mb-6 text-balance">{questions[currentQuestion]}</p>

          <RadioGroup value={answers[currentQuestion] || ""} onValueChange={handleAnswer} className="space-y-3">
            {options.map((option) => (
              <div
                key={option.value}
                className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                <RadioGroupItem value={option.value} id={option.value} />
                <Label htmlFor={option.value} className="flex-1 cursor-pointer">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>

          {hasError && (
            <div className="flex items-center space-x-2 text-red-600 mt-4 animate-slide-in">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">Please select an answer to continue</span>
            </div>
          )}
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="hover:scale-105 transition-transform bg-transparent"
          >
            Previous
          </Button>
          <Button onClick={handleNext} className="hover:scale-105 transition-transform">
            {currentQuestion === questions.length - 1 ? "Complete" : "Next"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
