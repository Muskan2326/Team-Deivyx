"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { CheckCircle, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface FoodSurveyProps {
  onComplete: () => void
}

const questions = [
  {
    type: "radio",
    question: "How many meals do you typically eat per day?",
    options: ["1-2 meals", "3 meals", "4-5 meals", "6+ meals"],
  },
  {
    type: "radio",
    question: "How often do you eat breakfast?",
    options: [
      "Never",
      "Rarely (1-2 times/week)",
      "Sometimes (3-4 times/week)",
      "Usually (5-6 times/week)",
      "Always (daily)",
    ],
  },
  {
    type: "checkbox",
    question: "Which dietary restrictions or preferences do you follow? (Select all that apply)",
    options: ["None", "Vegetarian", "Vegan", "Gluten-free", "Dairy-free", "Keto", "Paleo", "Other"],
  },
  {
    type: "radio",
    question: "How often do you eat fruits and vegetables?",
    options: ["Rarely", "1-2 servings/day", "3-4 servings/day", "5+ servings/day"],
  },
  {
    type: "radio",
    question: "How much water do you drink daily?",
    options: ["Less than 4 glasses", "4-6 glasses", "7-8 glasses", "More than 8 glasses"],
  },
  {
    type: "checkbox",
    question: "Do you have any food allergies? (Select all that apply)",
    options: ["None", "Nuts", "Dairy", "Gluten", "Shellfish", "Eggs", "Soy", "Other"],
  },
  {
    type: "radio",
    question: "How often do you eat out or order takeaway?",
    options: ["Never", "1-2 times/week", "3-4 times/week", "5-6 times/week", "Daily"],
  },
  {
    type: "radio",
    question: "How would you describe your relationship with food?",
    options: ["Very positive", "Mostly positive", "Neutral", "Sometimes challenging", "Often challenging"],
  },
  {
    type: "radio",
    question: "Do you experience emotional eating?",
    options: ["Never", "Rarely", "Sometimes", "Often", "Very often"],
  },
  {
    type: "radio",
    question: "How often do you skip meals?",
    options: ["Never", "Rarely", "Sometimes", "Often", "Very often"],
  },
]

export function FoodSurvey({ onComplete }: FoodSurveyProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string | string[]>>({})
  const [isCompleted, setIsCompleted] = useState(false)
  const [hasError, setHasError] = useState(false)

  const progress = ((currentQuestion + 1) / questions.length) * 100
  const question = questions[currentQuestion]

  const handleRadioAnswer = (value: string) => {
    setAnswers({ ...answers, [currentQuestion]: value })
    setHasError(false)
  }

  const handleCheckboxAnswer = (value: string, checked: boolean) => {
    const currentAnswers = (answers[currentQuestion] as string[]) || []
    let newAnswers: string[]

    if (checked) {
      newAnswers = [...currentAnswers, value]
    } else {
      newAnswers = currentAnswers.filter((answer) => answer !== value)
    }

    setAnswers({ ...answers, [currentQuestion]: newAnswers })
    setHasError(false)
  }

  const handleNext = () => {
    const currentAnswer = answers[currentQuestion]

    if (!currentAnswer || (Array.isArray(currentAnswer) && currentAnswer.length === 0)) {
      setHasError(true)
      return
    }

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setIsCompleted(true)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      setHasError(false)
    }
  }

  if (isCompleted) {
    return (
      <Card className="max-w-2xl mx-auto animate-slide-in">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl">Food Survey Complete</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <p className="text-lg text-muted-foreground mb-4">
              Thank you for sharing information about your eating habits and relationship with food.
            </p>
          </div>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h4 className="font-semibold text-green-800 mb-2">Your Nutrition Profile</h4>
            <p className="text-green-700 text-sm">
              Your responses help us understand your dietary patterns and can inform personalized wellness
              recommendations. Consider discussing nutrition goals with a healthcare provider or registered dietitian.
            </p>
          </div>

          <div className="flex space-x-4">
            <Button
              onClick={onComplete}
              variant="outline"
              className="flex-1 hover:scale-105 transition-transform bg-transparent"
            >
              Take Another Survey
            </Button>
            <Button className="flex-1 hover:scale-105 transition-transform">View Dashboard</Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between mb-4">
          <CardTitle className="text-xl">Nutrition & Eating Habits Survey</CardTitle>
          <div className="text-sm text-muted-foreground">
            {currentQuestion + 1} of {questions.length}
          </div>
        </div>
        <Progress value={progress} className="w-full" />
      </CardHeader>
      <CardContent className="space-y-6">
        <div className={cn("transition-all duration-300", hasError && "animate-shake")}>
          <h3 className="text-lg font-medium text-foreground mb-6 text-balance">{question.question}</h3>

          {question.type === "radio" ? (
            <RadioGroup
              value={(answers[currentQuestion] as string) || ""}
              onValueChange={handleRadioAnswer}
              className="space-y-3"
            >
              {question.options.map((option, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                >
                  <RadioGroupItem value={option} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          ) : (
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                >
                  <Checkbox
                    id={`checkbox-${index}`}
                    checked={((answers[currentQuestion] as string[]) || []).includes(option)}
                    onCheckedChange={(checked) => handleCheckboxAnswer(option, checked as boolean)}
                  />
                  <Label htmlFor={`checkbox-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </div>
          )}

          {hasError && (
            <div className="flex items-center space-x-2 text-red-600 mt-4 animate-slide-in">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">Please select at least one answer to continue</span>
            </div>
          )}
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="hover:scale-105 transition-transform bg-transparent"
          >
            Previous
          </Button>
          <Button onClick={handleNext} className="hover:scale-105 transition-transform">
            {currentQuestion === questions.length - 1 ? "Complete" : "Next"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
