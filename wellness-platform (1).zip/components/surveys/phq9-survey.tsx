"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CheckCircle, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface PHQ9SurveyProps {
  onComplete: () => void
}

const questions = [
  "Little interest or pleasure in doing things",
  "Feeling down, depressed, or hopeless",
  "Trouble falling or staying asleep, or sleeping too much",
  "Feeling tired or having little energy",
  "Poor appetite or overeating",
  "Feeling bad about yourself or that you are a failure or have let yourself or your family down",
  "Trouble concentrating on things, such as reading the newspaper or watching television",
  "Moving or speaking so slowly that other people could have noticed, or the opposite - being so fidgety or restless that you have been moving around a lot more than usual",
  "Thoughts that you would be better off dead, or of hurting yourself",
]

const options = [
  { value: "0", label: "Not at all", score: 0 },
  { value: "1", label: "Several days", score: 1 },
  { value: "2", label: "More than half the days", score: 2 },
  { value: "3", label: "Nearly every day", score: 3 },
]

export function PHQ9Survey({ onComplete }: PHQ9SurveyProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [isCompleted, setIsCompleted] = useState(false)
  const [hasError, setHasError] = useState(false)

  const progress = ((currentQuestion + 1) / questions.length) * 100

  const handleAnswer = (value: string) => {
    setAnswers({ ...answers, [currentQuestion]: value })
    setHasError(false)
  }

  const handleNext = () => {
    if (!answers[currentQuestion]) {
      setHasError(true)
      return
    }

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      setIsCompleted(true)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      setHasError(false)
    }
  }

  const calculateScore = () => {
    return Object.values(answers).reduce((total, answer) => {
      const option = options.find((opt) => opt.value === answer)
      return total + (option?.score || 0)
    }, 0)
  }

  const getScoreInterpretation = (score: number) => {
    if (score <= 4) return { level: "Minimal", color: "text-green-600", description: "Minimal depression symptoms" }
    if (score <= 9) return { level: "Mild", color: "text-yellow-600", description: "Mild depression symptoms" }
    if (score <= 14) return { level: "Moderate", color: "text-orange-600", description: "Moderate depression symptoms" }
    if (score <= 19)
      return { level: "Moderately Severe", color: "text-red-600", description: "Moderately severe depression symptoms" }
    return { level: "Severe", color: "text-red-800", description: "Severe depression symptoms" }
  }

  if (isCompleted) {
    const score = calculateScore()
    const interpretation = getScoreInterpretation(score)

    return (
      <Card className="max-w-2xl mx-auto animate-slide-in">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <CardTitle className="text-2xl">PHQ-9 Assessment Complete</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-foreground mb-2">{score}/27</div>
            <div className={cn("text-lg font-semibold", interpretation.color)}>{interpretation.level}</div>
            <p className="text-muted-foreground mt-2">{interpretation.description}</p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-semibold text-blue-800 mb-2">Important Note</h4>
            <p className="text-blue-700 text-sm">
              This screening tool is not a diagnosis. If you're experiencing significant symptoms or thoughts of
              self-harm, please reach out to a mental health professional or crisis helpline immediately.
            </p>
          </div>

          <div className="flex space-x-4">
            <Button
              onClick={onComplete}
              variant="outline"
              className="flex-1 hover:scale-105 transition-transform bg-transparent"
            >
              Take Another Survey
            </Button>
            <Button className="flex-1 hover:scale-105 transition-transform">View Dashboard</Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader>
        <div className="flex items-center justify-between mb-4">
          <CardTitle className="text-xl">PHQ-9 Depression Assessment</CardTitle>
          <div className="text-sm text-muted-foreground">
            {currentQuestion + 1} of {questions.length}
          </div>
        </div>
        <Progress value={progress} className="w-full" />
      </CardHeader>
      <CardContent className="space-y-6">
        <div className={cn("transition-all duration-300", hasError && "animate-shake")}>
          <h3 className="text-lg font-medium text-foreground mb-4">
            Over the last 2 weeks, how often have you been bothered by:
          </h3>
          <p className="text-foreground mb-6 text-balance">{questions[currentQuestion]}</p>

          <RadioGroup value={answers[currentQuestion] || ""} onValueChange={handleAnswer} className="space-y-3">
            {options.map((option) => (
              <div
                key={option.value}
                className="flex items-center space-x-2 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                <RadioGroupItem value={option.value} id={option.value} />
                <Label htmlFor={option.value} className="flex-1 cursor-pointer">
                  {option.label}
                </Label>
              </div>
            ))}
          </RadioGroup>

          {hasError && (
            <div className="flex items-center space-x-2 text-red-600 mt-4 animate-slide-in">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">Please select an answer to continue</span>
            </div>
          )}
        </div>

        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="hover:scale-105 transition-transform bg-transparent"
          >
            Previous
          </Button>
          <Button onClick={handleNext} className="hover:scale-105 transition-transform">
            {currentQuestion === questions.length - 1 ? "Complete" : "Next"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
