"use client"

import React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import {
  BookOpen,
  Plus,
  Search,
  CalendarIcon,
  TrendingUp,
  Heart,
  Smile,
  Meh,
  Frown,
  Angry,
  Lock,
  Save,
  Edit,
  Trash2,
  BarChart3,
  Target,
  Award,
} from "lucide-react"

interface DiaryEntry {
  id: string
  title: string
  content: string
  mood: 1 | 2 | 3 | 4 | 5
  emotions: string[]
  gratitude: string[]
  goals: string[]
  date: Date
  weather?: string
  sleepHours?: number
  energyLevel?: number
  stressLevel?: number
  tags: string[]
}

interface MoodStats {
  averageMood: number
  moodTrend: "up" | "down" | "stable"
  totalEntries: number
  streakDays: number
}

const moodIcons = {
  1: { icon: Angry, color: "text-red-500", label: "Very Bad" },
  2: { icon: Frown, color: "text-orange-500", label: "Bad" },
  3: { icon: Meh, color: "text-yellow-500", label: "Okay" },
  4: { icon: Smile, color: "text-green-500", label: "Good" },
  5: { icon: Heart, color: "text-pink-500", label: "Excellent" },
}

const emotionOptions = [
  "Happy",
  "Sad",
  "Anxious",
  "Excited",
  "Calm",
  "Stressed",
  "Grateful",
  "Lonely",
  "Confident",
  "Overwhelmed",
  "Peaceful",
  "Frustrated",
  "Hopeful",
  "Tired",
  "Energetic",
]

const journalPrompts = [
  "What am I most grateful for today?",
  "What challenged me today and how did I handle it?",
  "What made me smile today?",
  "How did I take care of myself today?",
  "What would I like to improve tomorrow?",
  "What am I looking forward to?",
  "How am I feeling right now and why?",
  "What lesson did I learn today?",
  "What are three good things that happened today?",
  "How did I show kindness today?",
]

export function PersonalDiary() {
  const [entries, setEntries] = useState<DiaryEntry[]>([])
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [showNewEntry, setShowNewEntry] = useState(false)
  const [editingEntry, setEditingEntry] = useState<DiaryEntry | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [moodFilter, setMoodFilter] = useState<string>("all")
  const [newEntry, setNewEntry] = useState<Partial<DiaryEntry>>({
    mood: 3,
    emotions: [],
    gratitude: [],
    goals: [],
    tags: [],
  })

  // Mock data for demonstration
  useEffect(() => {
    const mockEntries: DiaryEntry[] = [
      {
        id: "1",
        title: "A Peaceful Morning",
        content:
          "Started the day with meditation and felt really centered. The breathing exercises helped me feel more grounded.",
        mood: 4,
        emotions: ["Calm", "Peaceful", "Grateful"],
        gratitude: ["Morning sunshine", "Quiet time", "Good health"],
        goals: ["Continue meditation practice", "Drink more water"],
        date: new Date(2024, 11, 10),
        sleepHours: 8,
        energyLevel: 4,
        stressLevel: 2,
        tags: ["meditation", "morning", "wellness"],
      },
      {
        id: "2",
        title: "Challenging Day at Work",
        content:
          "Had a difficult presentation today but managed to get through it. Feeling proud of myself for not giving up.",
        mood: 3,
        emotions: ["Stressed", "Proud", "Tired"],
        gratitude: ["Supportive colleagues", "Learning opportunity"],
        goals: ["Practice public speaking", "Get better sleep"],
        date: new Date(2024, 11, 9),
        sleepHours: 6,
        energyLevel: 2,
        stressLevel: 4,
        tags: ["work", "challenge", "growth"],
      },
    ]
    setEntries(mockEntries)
  }, [])

  const getMoodStats = (): MoodStats => {
    if (entries.length === 0) {
      return { averageMood: 0, moodTrend: "stable", totalEntries: 0, streakDays: 0 }
    }

    const averageMood = entries.reduce((sum, entry) => sum + entry.mood, 0) / entries.length
    const recentEntries = entries.slice(0, 7)
    const olderEntries = entries.slice(7, 14)

    const recentAvg = recentEntries.reduce((sum, entry) => sum + entry.mood, 0) / recentEntries.length
    const olderAvg =
      olderEntries.length > 0
        ? olderEntries.reduce((sum, entry) => sum + entry.mood, 0) / olderEntries.length
        : recentAvg

    let moodTrend: "up" | "down" | "stable" = "stable"
    if (recentAvg > olderAvg + 0.2) moodTrend = "up"
    else if (recentAvg < olderAvg - 0.2) moodTrend = "down"

    // Calculate streak (simplified)
    const streakDays = Math.min(entries.length, 7)

    return {
      averageMood,
      moodTrend,
      totalEntries: entries.length,
      streakDays,
    }
  }

  const filteredEntries = entries.filter((entry) => {
    const matchesSearch =
      entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      entry.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesMood = moodFilter === "all" || entry.mood.toString() === moodFilter

    return matchesSearch && matchesMood
  })

  const saveEntry = () => {
    if (!newEntry.title || !newEntry.content) return

    const entry: DiaryEntry = {
      id: Date.now().toString(),
      title: newEntry.title,
      content: newEntry.content,
      mood: newEntry.mood || 3,
      emotions: newEntry.emotions || [],
      gratitude: newEntry.gratitude || [],
      goals: newEntry.goals || [],
      date: selectedDate,
      sleepHours: newEntry.sleepHours,
      energyLevel: newEntry.energyLevel,
      stressLevel: newEntry.stressLevel,
      tags: newEntry.tags || [],
    }

    if (editingEntry) {
      setEntries(entries.map((e) => (e.id === editingEntry.id ? { ...entry, id: editingEntry.id } : e)))
      setEditingEntry(null)
    } else {
      setEntries([entry, ...entries])
    }

    setNewEntry({ mood: 3, emotions: [], gratitude: [], goals: [], tags: [] })
    setShowNewEntry(false)
  }

  const deleteEntry = (id: string) => {
    setEntries(entries.filter((entry) => entry.id !== id))
  }

  const startEdit = (entry: DiaryEntry) => {
    setNewEntry(entry)
    setEditingEntry(entry)
    setShowNewEntry(true)
  }

  const addToArray = (field: keyof Pick<DiaryEntry, "emotions" | "gratitude" | "goals" | "tags">, value: string) => {
    if (!value.trim()) return
    const currentArray = (newEntry[field] as string[]) || []
    if (!currentArray.includes(value.trim())) {
      setNewEntry({
        ...newEntry,
        [field]: [...currentArray, value.trim()],
      })
    }
  }

  const removeFromArray = (
    field: keyof Pick<DiaryEntry, "emotions" | "gratitude" | "goals" | "tags">,
    value: string,
  ) => {
    const currentArray = (newEntry[field] as string[]) || []
    setNewEntry({
      ...newEntry,
      [field]: currentArray.filter((item) => item !== value),
    })
  }

  const stats = getMoodStats()

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-primary" />
            <span>Personal Diary</span>
            <Lock className="w-4 h-4 text-muted-foreground" />
          </CardTitle>
          <CardDescription>Your private space for reflection, mood tracking, and personal growth</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button onClick={() => setShowNewEntry(true)} className="hover:scale-105 transition-transform">
              <Plus className="w-4 h-4 mr-2" />
              New Entry
            </Button>
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search entries..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={moodFilter} onValueChange={setMoodFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by mood" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Moods</SelectItem>
                <SelectItem value="5">Excellent</SelectItem>
                <SelectItem value="4">Good</SelectItem>
                <SelectItem value="3">Okay</SelectItem>
                <SelectItem value="2">Bad</SelectItem>
                <SelectItem value="1">Very Bad</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="entries" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="entries">Entries ({entries.length})</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
        </TabsList>

        <TabsContent value="entries" className="space-y-4">
          {filteredEntries.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Entries Found</h3>
                <p className="text-muted-foreground mb-4">
                  {entries.length === 0
                    ? "Start your journaling journey by creating your first entry"
                    : "Try adjusting your search or filter criteria"}
                </p>
                <Button onClick={() => setShowNewEntry(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Entry
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredEntries.map((entry) => {
                const MoodIcon = moodIcons[entry.mood].icon
                return (
                  <Card key={entry.id} className="hover:shadow-lg transition-all duration-200">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <MoodIcon className={`w-6 h-6 ${moodIcons[entry.mood].color}`} />
                          <div>
                            <CardTitle className="text-lg">{entry.title}</CardTitle>
                            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                              <CalendarIcon className="w-3 h-3" />
                              <span>{entry.date.toLocaleDateString()}</span>
                              <Badge variant="outline" className="text-xs">
                                {moodIcons[entry.mood].label}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm" onClick={() => startEdit(entry)}>
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteEntry(entry.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm leading-relaxed">{entry.content}</p>

                      {entry.emotions.length > 0 && (
                        <div>
                          <h4 className="text-xs font-medium text-muted-foreground mb-1">Emotions</h4>
                          <div className="flex flex-wrap gap-1">
                            {entry.emotions.map((emotion) => (
                              <Badge key={emotion} variant="secondary" className="text-xs">
                                {emotion}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {entry.gratitude.length > 0 && (
                        <div>
                          <h4 className="text-xs font-medium text-muted-foreground mb-1">Grateful For</h4>
                          <div className="flex flex-wrap gap-1">
                            {entry.gratitude.map((item) => (
                              <Badge key={item} variant="outline" className="text-xs border-green-200 text-green-800">
                                {item}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {entry.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {entry.tags.map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs">
                              #{tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          {/* Mood Statistics */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-primary">{stats.averageMood.toFixed(1)}</div>
                <div className="text-sm text-muted-foreground">Average Mood</div>
                <div className="flex justify-center mt-2">
                  {stats.moodTrend === "up" && <TrendingUp className="w-4 h-4 text-green-500" />}
                  {stats.moodTrend === "down" && <TrendingUp className="w-4 h-4 text-red-500 rotate-180" />}
                  {stats.moodTrend === "stable" && <div className="w-4 h-4 bg-gray-400 rounded-full" />}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-blue-600">{stats.totalEntries}</div>
                <div className="text-sm text-muted-foreground">Total Entries</div>
                <BarChart3 className="w-4 h-4 text-blue-500 mx-auto mt-2" />
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-green-600">{stats.streakDays}</div>
                <div className="text-sm text-muted-foreground">Day Streak</div>
                <Award className="w-4 h-4 text-green-500 mx-auto mt-2" />
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {entries.length > 0
                    ? Math.round((entries.filter((e) => e.mood >= 4).length / entries.length) * 100)
                    : 0}
                  %
                </div>
                <div className="text-sm text-muted-foreground">Good Days</div>
                <Target className="w-4 h-4 text-purple-500 mx-auto mt-2" />
              </CardContent>
            </Card>
          </div>

          {/* Mood Chart Placeholder */}
          <Card>
            <CardHeader>
              <CardTitle>Mood Trends</CardTitle>
              <CardDescription>Your mood patterns over time</CardDescription>
            </CardHeader>
            <CardContent className="text-center py-12">
              <BarChart3 className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Mood Chart Coming Soon</h3>
              <p className="text-muted-foreground">Visual charts and insights about your mood patterns and trends</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar">
          <Card>
            <CardHeader>
              <CardTitle>Entry Calendar</CardTitle>
              <CardDescription>View your journaling activity by date</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col lg:flex-row gap-6">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  className="rounded-md border"
                />
                <div className="flex-1">
                  <h3 className="font-semibold mb-4">Entries for {selectedDate.toLocaleDateString()}</h3>
                  {entries
                    .filter((entry) => entry.date.toDateString() === selectedDate.toDateString())
                    .map((entry) => (
                      <Card key={entry.id} className="mb-3">
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-2 mb-2">
                            {React.createElement(moodIcons[entry.mood].icon, {
                              className: `w-4 h-4 ${moodIcons[entry.mood].color}`,
                            })}
                            <span className="font-medium">{entry.title}</span>
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-2">{entry.content}</p>
                        </CardContent>
                      </Card>
                    ))}
                  {entries.filter((entry) => entry.date.toDateString() === selectedDate.toDateString()).length ===
                    0 && <p className="text-muted-foreground">No entries for this date</p>}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* New/Edit Entry Dialog */}
      <Dialog open={showNewEntry} onOpenChange={setShowNewEntry}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingEntry ? "Edit Entry" : "New Diary Entry"}</DialogTitle>
            <DialogDescription>{selectedDate.toLocaleDateString()} • Private and secure</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Title</label>
              <Input
                value={newEntry.title || ""}
                onChange={(e) => setNewEntry({ ...newEntry, title: e.target.value })}
                placeholder="How was your day?"
              />
            </div>

            <div>
              <label className="text-sm font-medium">How are you feeling? (1-5)</label>
              <div className="flex space-x-2 mt-2">
                {Object.entries(moodIcons).map(([mood, { icon: Icon, color, label }]) => (
                  <Button
                    key={mood}
                    variant={newEntry.mood === Number.parseInt(mood) ? "default" : "outline"}
                    size="sm"
                    onClick={() => setNewEntry({ ...newEntry, mood: Number.parseInt(mood) as 1 | 2 | 3 | 4 | 5 })}
                    className="flex flex-col items-center p-3 h-auto"
                  >
                    <Icon className={`w-5 h-5 ${color}`} />
                    <span className="text-xs mt-1">{label}</span>
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium">Writing Prompts</label>
              <div className="grid grid-cols-1 gap-2 mt-2">
                {journalPrompts.slice(0, 3).map((prompt, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => setNewEntry({ ...newEntry, content: prompt + "\n\n" })}
                    className="text-left justify-start h-auto p-2 text-xs bg-transparent"
                  >
                    {prompt}
                  </Button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium">Your thoughts</label>
              <Textarea
                value={newEntry.content || ""}
                onChange={(e) => setNewEntry({ ...newEntry, content: e.target.value })}
                placeholder="Write about your day, feelings, thoughts, or experiences..."
                className="min-h-[150px] resize-none"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Emotions</label>
                <Select onValueChange={(value) => addToArray("emotions", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Add emotions" />
                  </SelectTrigger>
                  <SelectContent>
                    {emotionOptions.map((emotion) => (
                      <SelectItem key={emotion} value={emotion}>
                        {emotion}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex flex-wrap gap-1 mt-2">
                  {(newEntry.emotions || []).map((emotion) => (
                    <Badge
                      key={emotion}
                      variant="secondary"
                      className="text-xs cursor-pointer"
                      onClick={() => removeFromArray("emotions", emotion)}
                    >
                      {emotion} ×
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-medium">Grateful for</label>
                <Input
                  placeholder="Add something you're grateful for"
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      addToArray("gratitude", e.currentTarget.value)
                      e.currentTarget.value = ""
                    }
                  }}
                />
                <div className="flex flex-wrap gap-1 mt-2">
                  {(newEntry.gratitude || []).map((item) => (
                    <Badge
                      key={item}
                      variant="outline"
                      className="text-xs cursor-pointer border-green-200 text-green-800"
                      onClick={() => removeFromArray("gratitude", item)}
                    >
                      {item} ×
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex space-x-2">
              <Button onClick={saveEntry} disabled={!newEntry.title || !newEntry.content}>
                <Save className="w-4 h-4 mr-2" />
                {editingEntry ? "Update Entry" : "Save Entry"}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowNewEntry(false)
                  setEditingEntry(null)
                  setNewEntry({ mood: 3, emotions: [], gratitude: [], goals: [], tags: [] })
                }}
                className="bg-transparent"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
