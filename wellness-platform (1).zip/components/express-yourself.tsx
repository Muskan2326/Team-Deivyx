"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Palette, PenTool, Type, Save, Download, Share2, Trash2, Undo, Redo, Heart, Music, Camera } from "lucide-react"

interface CreativeWork {
  id: string
  title: string
  type: "drawing" | "writing" | "music" | "photo"
  content: string
  mood: "happy" | "calm" | "reflective" | "energetic" | "peaceful"
  tags: string[]
  createdAt: Date
  isPublic: boolean
}

interface DrawingTool {
  type: "pen" | "brush" | "eraser" | "shape"
  size: number
  color: string
  opacity: number
}

const colorPalette = [
  "#000000",
  "#FF0000",
  "#00FF00",
  "#0000FF",
  "#FFFF00",
  "#FF00FF",
  "#00FFFF",
  "#FFA500",
  "#800080",
  "#FFC0CB",
  "#A52A2A",
  "#808080",
  "#FFFFFF",
]

const moodColors = {
  happy: "bg-yellow-100 text-yellow-800 border-yellow-200",
  calm: "bg-blue-100 text-blue-800 border-blue-200",
  reflective: "bg-purple-100 text-purple-800 border-purple-200",
  energetic: "bg-red-100 text-red-800 border-red-200",
  peaceful: "bg-green-100 text-green-800 border-green-200",
}

// Drawing Canvas Component
function DrawingCanvas({ onSave }: { onSave: (dataUrl: string) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [tool, setTool] = useState<DrawingTool>({
    type: "pen",
    size: 5,
    color: "#000000",
    opacity: 1,
  })
  const [history, setHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    canvas.width = 600
    canvas.height = 400

    // Set white background
    ctx.fillStyle = "#FFFFFF"
    ctx.fillRect(0, 0, canvas.width, canvas.height)

    // Save initial state
    saveToHistory()
  }, [])

  const saveToHistory = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const dataUrl = canvas.toDataURL()
    const newHistory = history.slice(0, historyIndex + 1)
    newHistory.push(dataUrl)
    setHistory(newHistory)
    setHistoryIndex(newHistory.length - 1)
  }

  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1)
      loadFromHistory(historyIndex - 1)
    }
  }

  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1)
      loadFromHistory(historyIndex + 1)
    }
  }

  const loadFromHistory = (index: number) => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext("2d")
    if (!canvas || !ctx) return

    const img = new Image()
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      ctx.drawImage(img, 0, 0)
    }
    img.src = history[index]
  }

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true)
    draw(e)
  }

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return

    const canvas = canvasRef.current
    const ctx = canvas?.getContext("2d")
    if (!canvas || !ctx) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    ctx.globalAlpha = tool.opacity
    ctx.lineWidth = tool.size
    ctx.lineCap = "round"

    if (tool.type === "eraser") {
      ctx.globalCompositeOperation = "destination-out"
    } else {
      ctx.globalCompositeOperation = "source-over"
      ctx.strokeStyle = tool.color
    }

    ctx.lineTo(x, y)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(x, y)
  }

  const stopDrawing = () => {
    if (isDrawing) {
      setIsDrawing(false)
      const ctx = canvasRef.current?.getContext("2d")
      if (ctx) {
        ctx.beginPath()
      }
      saveToHistory()
    }
  }

  const clearCanvas = () => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext("2d")
    if (!canvas || !ctx) return

    ctx.fillStyle = "#FFFFFF"
    ctx.fillRect(0, 0, canvas.width, canvas.height)
    saveToHistory()
  }

  const saveDrawing = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const dataUrl = canvas.toDataURL()
    onSave(dataUrl)
  }

  return (
    <div className="space-y-4">
      {/* Drawing Tools */}
      <div className="flex flex-wrap gap-4 p-4 bg-muted/50 rounded-lg">
        <div className="flex space-x-2">
          <Button
            variant={tool.type === "pen" ? "default" : "outline"}
            size="sm"
            onClick={() => setTool({ ...tool, type: "pen" })}
          >
            <PenTool className="w-4 h-4" />
          </Button>
          <Button
            variant={tool.type === "brush" ? "default" : "outline"}
            size="sm"
            onClick={() => setTool({ ...tool, type: "brush" })}
          >
            <Palette className="w-4 h-4" />
          </Button>
          <Button
            variant={tool.type === "eraser" ? "default" : "outline"}
            size="sm"
            onClick={() => setTool({ ...tool, type: "eraser" })}
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-sm">Size:</span>
          <Slider
            value={[tool.size]}
            onValueChange={(value) => setTool({ ...tool, size: value[0] })}
            max={50}
            min={1}
            step={1}
            className="w-20"
          />
          <span className="text-sm w-8">{tool.size}</span>
        </div>

        <div className="flex space-x-1">
          {colorPalette.map((color) => (
            <button
              key={color}
              onClick={() => setTool({ ...tool, color })}
              className={`w-6 h-6 rounded border-2 ${tool.color === color ? "border-gray-800" : "border-gray-300"}`}
              style={{ backgroundColor: color }}
            />
          ))}
        </div>

        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={undo} disabled={historyIndex <= 0}>
            <Undo className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={redo} disabled={historyIndex >= history.length - 1}>
            <Redo className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={clearCanvas}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Canvas */}
      <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 bg-white">
        <canvas
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          className="border border-gray-200 rounded cursor-crosshair"
        />
      </div>

      {/* Save Button */}
      <div className="flex justify-center">
        <Button onClick={saveDrawing} className="hover:scale-105 transition-transform">
          <Save className="w-4 h-4 mr-2" />
          Save Drawing
        </Button>
      </div>
    </div>
  )
}

// Writing Editor Component
function WritingEditor({ onSave }: { onSave: (content: string) => void }) {
  const [content, setContent] = useState("")
  const [wordCount, setWordCount] = useState(0)

  useEffect(() => {
    const words = content
      .trim()
      .split(/\s+/)
      .filter((word) => word.length > 0)
    setWordCount(words.length)
  }, [content])

  const saveWriting = () => {
    if (content.trim()) {
      onSave(content)
    }
  }

  const writingPrompts = [
    "What made you smile today?",
    "Describe a place where you feel most peaceful.",
    "Write about a challenge you overcame.",
    "What are three things you're grateful for?",
    "Describe your ideal day.",
    "Write a letter to your future self.",
    "What does happiness mean to you?",
    "Describe a moment when you felt proud of yourself.",
  ]

  return (
    <div className="space-y-4">
      {/* Writing Prompts */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Writing Prompts</CardTitle>
          <CardDescription>Need inspiration? Try one of these prompts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-2">
            {writingPrompts.map((prompt, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                onClick={() => setContent(prompt + "\n\n")}
                className="text-left justify-start h-auto p-3 bg-transparent"
              >
                {prompt}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Text Editor */}
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <label className="text-sm font-medium">Your Writing</label>
          <span className="text-sm text-muted-foreground">{wordCount} words</span>
        </div>
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Start writing your thoughts, feelings, or creative ideas..."
          className="min-h-[300px] resize-none"
        />
      </div>

      {/* Save Button */}
      <div className="flex justify-center">
        <Button onClick={saveWriting} disabled={!content.trim()} className="hover:scale-105 transition-transform">
          <Save className="w-4 h-4 mr-2" />
          Save Writing
        </Button>
      </div>
    </div>
  )
}

export function ExpressYourself() {
  const [works, setWorks] = useState<CreativeWork[]>([])
  const [selectedWork, setSelectedWork] = useState<CreativeWork | null>(null)
  const [showSaveDialog, setShowSaveDialog] = useState(false)
  const [newWork, setNewWork] = useState<Partial<CreativeWork>>({})

  const saveWork = (content: string, type: "drawing" | "writing") => {
    setNewWork({ content, type })
    setShowSaveDialog(true)
  }

  const confirmSave = () => {
    if (!newWork.content || !newWork.type) return

    const work: CreativeWork = {
      id: Date.now().toString(),
      title: newWork.title || `Untitled ${newWork.type}`,
      type: newWork.type,
      content: newWork.content,
      mood: (newWork.mood as any) || "peaceful",
      tags: newWork.tags || [],
      createdAt: new Date(),
      isPublic: newWork.isPublic || false,
    }

    setWorks([work, ...works])
    setShowSaveDialog(false)
    setNewWork({})
  }

  const deleteWork = (id: string) => {
    setWorks(works.filter((work) => work.id !== id))
    if (selectedWork?.id === id) {
      setSelectedWork(null)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Palette className="w-5 h-5 text-primary" />
            <span>Express Yourself</span>
          </CardTitle>
          <CardDescription>
            Create art, write your thoughts, or express your feelings through creative activities
          </CardDescription>
        </CardHeader>
      </Card>

      <Tabs defaultValue="create" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="create">Create</TabsTrigger>
          <TabsTrigger value="gallery">My Gallery ({works.length})</TabsTrigger>
          <TabsTrigger value="community">Community</TabsTrigger>
        </TabsList>

        <TabsContent value="create" className="space-y-6">
          <Tabs defaultValue="drawing" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="drawing">Drawing</TabsTrigger>
              <TabsTrigger value="writing">Writing</TabsTrigger>
              <TabsTrigger value="music">Music</TabsTrigger>
              <TabsTrigger value="photo">Photo</TabsTrigger>
            </TabsList>

            <TabsContent value="drawing">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <PenTool className="w-5 h-5" />
                    <span>Digital Drawing</span>
                  </CardTitle>
                  <CardDescription>Express yourself through colors and shapes</CardDescription>
                </CardHeader>
                <CardContent>
                  <DrawingCanvas onSave={(dataUrl) => saveWork(dataUrl, "drawing")} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="writing">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Type className="w-5 h-5" />
                    <span>Creative Writing</span>
                  </CardTitle>
                  <CardDescription>Share your thoughts, stories, and feelings through words</CardDescription>
                </CardHeader>
                <CardContent>
                  <WritingEditor onSave={(content) => saveWork(content, "writing")} />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="music">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Music className="w-5 h-5" />
                    <span>Music & Sound</span>
                  </CardTitle>
                  <CardDescription>Create melodies or record voice notes</CardDescription>
                </CardHeader>
                <CardContent className="text-center py-12">
                  <Music className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Music Studio Coming Soon</h3>
                  <p className="text-muted-foreground">
                    Create music, record voice notes, and explore sound therapy tools
                  </p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="photo">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Camera className="w-5 h-5" />
                    <span>Photo Journal</span>
                  </CardTitle>
                  <CardDescription>Capture moments and add reflective captions</CardDescription>
                </CardHeader>
                <CardContent className="text-center py-12">
                  <Camera className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Photo Journal Coming Soon</h3>
                  <p className="text-muted-foreground">
                    Upload photos and create visual stories with meaningful captions
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>

        <TabsContent value="gallery" className="space-y-4">
          {works.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Palette className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Your Gallery is Empty</h3>
                <p className="text-muted-foreground mb-4">Start creating to see your artwork and writings here</p>
                <Button>Create Your First Piece</Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {works.map((work) => (
                <Card key={work.id} className="hover:shadow-lg transition-all duration-200 hover:scale-[1.02]">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">{work.title}</CardTitle>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className={moodColors[work.mood]}>
                            {work.mood}
                          </Badge>
                          <Badge variant="secondary">{work.type}</Badge>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteWork(work.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {work.type === "drawing" ? (
                        <img
                          src={work.content || "/placeholder.svg"}
                          alt={work.title}
                          className="w-full h-32 object-cover rounded border"
                        />
                      ) : (
                        <div className="bg-muted/50 p-3 rounded text-sm line-clamp-3">{work.content}</div>
                      )}
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>{work.createdAt.toLocaleDateString()}</span>
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="sm">
                            <Share2 className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="community">
          <Card>
            <CardHeader>
              <CardTitle>Community Gallery</CardTitle>
              <CardDescription>Discover and appreciate creative works shared by the community</CardDescription>
            </CardHeader>
            <CardContent className="text-center py-12">
              <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Community Gallery Coming Soon</h3>
              <p className="text-muted-foreground">
                Share your creations and explore inspiring works from other community members
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Your Creation</DialogTitle>
            <DialogDescription>Add details about your {newWork.type}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Title</label>
              <Input
                value={newWork.title || ""}
                onChange={(e) => setNewWork({ ...newWork, title: e.target.value })}
                placeholder={`My ${newWork.type}`}
              />
            </div>
            <div>
              <label className="text-sm font-medium">Mood</label>
              <Select value={newWork.mood} onValueChange={(mood) => setNewWork({ ...newWork, mood })}>
                <SelectTrigger>
                  <SelectValue placeholder="How does this make you feel?" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="happy">Happy</SelectItem>
                  <SelectItem value="calm">Calm</SelectItem>
                  <SelectItem value="reflective">Reflective</SelectItem>
                  <SelectItem value="energetic">Energetic</SelectItem>
                  <SelectItem value="peaceful">Peaceful</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isPublic"
                checked={newWork.isPublic || false}
                onChange={(e) => setNewWork({ ...newWork, isPublic: e.target.checked })}
              />
              <label htmlFor="isPublic" className="text-sm">
                Share with community (optional)
              </label>
            </div>
            <div className="flex space-x-2">
              <Button onClick={confirmSave} className="flex-1">
                Save
              </Button>
              <Button variant="outline" onClick={() => setShowSaveDialog(false)} className="bg-transparent">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
