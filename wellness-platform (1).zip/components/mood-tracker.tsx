"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts"
import { Calendar, TrendingUp, Smile, Meh, Frown } from "lucide-react"

const moodData = [
  { date: "Mon", mood: 7, energy: 6, anxiety: 3, sleep: 8 },
  { date: "Tue", mood: 6, energy: 5, anxiety: 4, sleep: 7 },
  { date: "Wed", mood: 8, energy: 7, anxiety: 2, sleep: 8 },
  { date: "Thu", mood: 7, energy: 6, anxiety: 3, sleep: 6 },
  { date: "Fri", mood: 9, energy: 8, anxiety: 1, sleep: 9 },
  { date: "Sat", mood: 8, energy: 7, anxiety: 2, sleep: 8 },
  { date: "Sun", mood: 7, energy: 6, anxiety: 3, sleep: 7 },
]

const weeklyData = [
  { week: "Week 1", mood: 6.2, energy: 5.8, anxiety: 4.1, sleep: 6.9 },
  { week: "Week 2", mood: 6.8, energy: 6.2, anxiety: 3.5, sleep: 7.2 },
  { week: "Week 3", mood: 7.1, energy: 6.8, anxiety: 3.2, sleep: 7.5 },
  { week: "Week 4", mood: 7.4, energy: 7.1, anxiety: 2.8, sleep: 7.8 },
]

type ViewType = "daily" | "weekly"

export function MoodTracker() {
  const [viewType, setViewType] = useState<ViewType>("daily")
  const [animationKey, setAnimationKey] = useState(0)

  const data = viewType === "daily" ? moodData : weeklyData
  const xAxisKey = viewType === "daily" ? "date" : "week"

  useEffect(() => {
    setAnimationKey((prev) => prev + 1)
  }, [viewType])

  const getMoodIcon = (mood: number) => {
    if (mood >= 8) return <Smile className="w-4 h-4 text-green-500" />
    if (mood >= 6) return <Meh className="w-4 h-4 text-yellow-500" />
    return <Frown className="w-4 h-4 text-red-500" />
  }

  const currentMood = data[data.length - 1]?.mood || 0
  const previousMood = data[data.length - 2]?.mood || 0
  const moodChange = currentMood - previousMood

  return (
    <Card className="animate-slide-in">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              <span>Mood Tracking</span>
            </CardTitle>
            <CardDescription>Your emotional well-being trends over time</CardDescription>
          </div>
          <div className="flex space-x-2">
            <Button
              variant={viewType === "daily" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewType("daily")}
              className="hover:scale-105 transition-transform"
            >
              Daily
            </Button>
            <Button
              variant={viewType === "weekly" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewType("weekly")}
              className="hover:scale-105 transition-transform"
            >
              Weekly
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Status */}
        <div className="flex items-center justify-between p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg">
          <div className="flex items-center space-x-3">
            {getMoodIcon(currentMood)}
            <div>
              <div className="font-semibold text-foreground">Current Mood: {currentMood}/10</div>
              <div className="text-sm text-muted-foreground">
                {moodChange > 0 ? "↗" : moodChange < 0 ? "↘" : "→"} {Math.abs(moodChange).toFixed(1)} from last{" "}
                {viewType === "daily" ? "day" : "week"}
              </div>
            </div>
          </div>
          <Badge variant={moodChange >= 0 ? "default" : "secondary"} className="animate-gentle-pulse">
            {moodChange >= 0 ? "Improving" : "Needs Attention"}
          </Badge>
        </div>

        {/* Chart */}
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart key={animationKey} data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="moodGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a4d7e1" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#a4d7e1" stopOpacity={0.1} />
                </linearGradient>
                <linearGradient id="energyGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#ffb3b3" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#ffb3b3" stopOpacity={0.1} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey={xAxisKey} stroke="#6b7280" />
              <YAxis domain={[0, 10]} stroke="#6b7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#f9f2f9",
                  border: "1px solid #e5e7eb",
                  borderRadius: "8px",
                }}
              />
              <Area
                type="monotone"
                dataKey="mood"
                stroke="#a4d7e1"
                strokeWidth={3}
                fill="url(#moodGradient)"
                animationDuration={1500}
              />
              <Area
                type="monotone"
                dataKey="energy"
                stroke="#ffb3b3"
                strokeWidth={2}
                fill="url(#energyGradient)"
                animationDuration={1500}
                animationDelay={300}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center space-x-6 text-sm">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded-full" />
            <span>Mood</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-secondary rounded-full" />
            <span>Energy</span>
          </div>
          <div className="flex items-center space-x-2">
            <Calendar className="w-3 h-3 text-muted-foreground" />
            <span>Last 7 {viewType === "daily" ? "days" : "weeks"}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
