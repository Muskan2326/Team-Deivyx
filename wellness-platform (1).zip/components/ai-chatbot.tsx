"use client"

import type React from "react"

import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, Bot, User, Heart, Sparkles, Mic, MicOff } from "lucide-react"
import { cn } from "@/lib/utils"

interface Message {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
  isAnimating?: boolean
}

const aiResponses = [
  "I'm here to listen and support you. How are you feeling today?",
  "That sounds like you're going through a lot. Remember, it's okay to feel this way, and you're not alone.",
  "Thank you for sharing that with me. What would help you feel a little better right now?",
  "I hear you, and your feelings are completely valid. Have you tried any breathing exercises today?",
  "It's wonderful that you're taking care of your mental health. What's one small thing that brought you joy recently?",
  "Remember, healing isn't linear. Every step forward, no matter how small, is progress worth celebrating.",
  "I'm proud of you for reaching out. That takes courage. What support do you need most right now?",
  "Your wellness journey is unique to you. What does self-care look like for you today?",
]

export function AIChatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "Hello! I'm your AI wellness companion. I'm here to listen, support, and help you on your mental health journey. How are you feeling today?",
      sender: "ai",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const [typingDots, setTypingDots] = useState(1)
  const [isRecording, setIsRecording] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = useCallback(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]")
      if (scrollContainer) {
        scrollContainer.scrollTo({
          top: scrollContainer.scrollHeight,
          behavior: "smooth",
        })
      }
    }
  }, [])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isTyping) {
      interval = setInterval(() => {
        setTypingDots((prev) => (prev >= 3 ? 1 : prev + 1))
      }, 500)
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isTyping])

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping, scrollToBottom])

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: "user",
      timestamp: new Date(),
      isAnimating: true,
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    setTimeout(() => {
      setMessages((prev) => prev.map((msg) => (msg.id === userMessage.id ? { ...msg, isAnimating: false } : msg)))
    }, 500)

    const thinkingTime = 1500 + Math.random() * 2500
    await new Promise((resolve) => setTimeout(resolve, thinkingTime))

    const aiResponse: Message = {
      id: (Date.now() + 1).toString(),
      content: aiResponses[Math.floor(Math.random() * aiResponses.length)],
      sender: "ai",
      timestamp: new Date(),
      isAnimating: true,
    }

    setIsTyping(false)
    setMessages((prev) => [...prev, aiResponse])

    setTimeout(() => {
      setMessages((prev) => prev.map((msg) => (msg.id === aiResponse.id ? { ...msg, isAnimating: false } : msg)))
    }, 500)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    if (!isRecording) {
      setTimeout(() => {
        setIsRecording(false)
        setInputValue("I'm feeling a bit overwhelmed today...")
      }, 3000)
    }
  }

  return (
    <Card className={cn("mx-auto transition-all duration-500 ease-in-out", isExpanded ? "max-w-4xl" : "max-w-2xl")}>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="relative w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-primary animate-pulse" />
              <div className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping" />
            </div>
            <span>AI Wellness Friend</span>
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              <span className="text-sm text-foreground/80">Online</span>
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="hover:scale-105 transition-transform duration-200"
          >
            {isExpanded ? "Minimize" : "Expand"}
          </Button>
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        <ScrollArea
          ref={scrollAreaRef}
          className={cn("border rounded-lg p-4 transition-all duration-500", isExpanded ? "h-96" : "h-64")}
        >
          <div className="space-y-4">
            {messages.map((message, index) => (
              <div
                key={message.id}
                className={cn(
                  "flex items-start space-x-3 transition-all duration-500 ease-out",
                  message.sender === "user" ? "flex-row-reverse space-x-reverse" : "",
                  message.isAnimating ? "animate-slide-in-bottom opacity-0" : "opacity-100",
                )}
                style={{
                  animationDelay: `${index * 100}ms`,
                  animationFillMode: "forwards",
                }}
              >
                <Avatar className="w-8 h-8 transition-transform hover:scale-110">
                  <AvatarFallback className={message.sender === "ai" ? "bg-primary/20" : "bg-secondary/20"}>
                    {message.sender === "ai" ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                  </AvatarFallback>
                </Avatar>
                <div
                  className={cn(
                    "max-w-[80%] rounded-lg p-3 transition-all duration-300 hover:scale-[1.02] hover:shadow-md",
                    message.sender === "ai"
                      ? "bg-primary/20 backdrop-blur-sm text-foreground"
                      : "bg-secondary/20 backdrop-blur-sm text-foreground ml-auto",
                  )}
                >
                  <p className="text-sm leading-relaxed">{message.content}</p>
                  <p className="text-xs text-foreground/70 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-start space-x-3 animate-fade-in">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-primary/20">
                    <Bot className="w-4 h-4 animate-pulse" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-primary/20 backdrop-blur-sm rounded-lg p-3 min-w-[60px]">
                  <div className="flex space-x-1 items-center">
                    {[1, 2, 3].map((dot) => (
                      <div
                        key={dot}
                        className={cn(
                          "w-2 h-2 bg-primary rounded-full transition-all duration-300",
                          typingDots >= dot ? "animate-bounce opacity-100" : "opacity-30",
                        )}
                        style={{ animationDelay: `${(dot - 1) * 0.1}s` }}
                      />
                    ))}
                    <span className="text-xs text-primary/70 ml-2">AI is typing...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        <div className="flex space-x-2">
          <div className="flex-1 relative">
            <Input
              ref={inputRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={isRecording ? "Recording..." : "Share what's on your mind..."}
              className={cn(
                "transition-all duration-300 focus:scale-[1.02] pr-12",
                isRecording && "border-red-300 bg-red-50",
              )}
              disabled={isTyping || isRecording}
            />
            <Button
              size="sm"
              variant="ghost"
              onClick={toggleRecording}
              className={cn(
                "absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0 transition-colors",
                isRecording ? "text-red-500 animate-pulse" : "text-muted-foreground hover:text-primary",
              )}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </Button>
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isTyping || isRecording}
            className="hover:scale-105 transition-transform duration-200"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInputValue("I'm feeling anxious today")}
            className="hover:scale-105 transition-transform bg-transparent"
          >
            <Heart className="w-3 h-3 mr-1" />
            I'm feeling anxious
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInputValue("I need some motivation")}
            className="hover:scale-105 transition-transform bg-transparent"
          >
            <Sparkles className="w-3 h-3 mr-1" />I need motivation
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setInputValue("Can you help me with breathing exercises?")}
            className="hover:scale-105 transition-transform bg-transparent"
          >
            <Bot className="w-3 h-3 mr-1" />
            Breathing exercises
          </Button>
        </div>

        <div className="bg-muted/50 rounded-md p-2">
          <p className="text-xs text-foreground/80 text-center">
            This AI companion provides supportive conversations but is not a replacement for professional mental health
            care.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
