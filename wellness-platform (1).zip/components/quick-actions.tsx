"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MessageCircle, ClipboardList, Users, Phone, Calendar, Heart } from "lucide-react"

export function QuickActions() {
  const actions = [
    {
      icon: Heart,
      title: "Daily Check-in",
      description: "Log your mood and energy",
      action: "Start Check-in",
      color: "bg-red-100 text-red-800",
      urgent: false,
    },
    {
      icon: MessageCircle,
      title: "Chat with AI",
      description: "Get instant support",
      action: "Start Chat",
      color: "bg-blue-100 text-blue-800",
      urgent: false,
    },
    {
      icon: Users,
      title: "Connect with Volunteer",
      description: "3 volunteers online",
      action: "Connect Now",
      color: "bg-green-100 text-green-800",
      urgent: false,
    },
    {
      icon: ClipboardList,
      title: "Take Assessment",
      description: "PHQ-9 due in 2 days",
      action: "Take Survey",
      color: "bg-yellow-100 text-yellow-800",
      urgent: true,
    },
    {
      icon: Phone,
      title: "Crisis Support",
      description: "24/7 helpline available",
      action: "Get Help",
      color: "bg-red-100 text-red-800",
      urgent: false,
    },
    {
      icon: Calendar,
      title: "Schedule Session",
      description: "Book with counselor",
      action: "Schedule",
      color: "bg-purple-100 text-purple-800",
      urgent: false,
    },
  ]

  return (
    <Card className="animate-slide-in">
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
        <CardDescription>Access your wellness tools and support</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {actions.map((action, index) => {
          const Icon = action.icon
          return (
            <div
              key={index}
              className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-all hover:scale-105 cursor-pointer animate-slide-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <div className="font-medium text-foreground">{action.title}</div>
                    {action.urgent && (
                      <Badge variant="destructive" className="text-xs">
                        Due Soon
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">{action.description}</div>
                </div>
              </div>
              <Button size="sm" variant="outline" className="hover:scale-105 transition-transform bg-transparent">
                {action.action}
              </Button>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}
