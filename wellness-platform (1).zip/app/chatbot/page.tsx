"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Navigation } from "@/components/navigation"
import { BackgroundSystem } from "@/components/background-system"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send, Bot, User, Heart } from "lucide-react"

interface Message {
  id: string
  content: string
  sender: "user" | "ai"
  timestamp: Date
}

export default function ChatbotPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "Hello! I'm your AI wellness companion. How are you feeling today? I'm here to listen and support you. 💜",
      sender: "ai",
      timestamp: new Date(),
    },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate AI response with typing delay
    setTimeout(() => {
      const aiResponses = [
        "I understand how you're feeling. It's completely normal to have these emotions. Would you like to talk more about what's on your mind?",
        "Thank you for sharing that with me. Your feelings are valid, and I'm here to support you through this. What would help you feel better right now?",
        "That sounds challenging. Remember that you're stronger than you think, and it's okay to take things one step at a time. How can I help you today?",
        "I appreciate you opening up to me. Mental wellness is a journey, and every small step counts. What's one positive thing that happened today?",
        "Your mental health matters, and so do you. It's brave of you to reach out. Would you like to try a breathing exercise together?",
      ]

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponses[Math.floor(Math.random() * aiResponses.length)],
        sender: "ai",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, aiMessage])
      setIsTyping(false)
    }, 2000)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="min-h-screen relative">
      <BackgroundSystem />
      <Navigation />

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="bg-white/90 backdrop-blur-md rounded-t-3xl p-6 border-b border-purple-100">
            <div className="flex items-center space-x-4">
              <Avatar className="w-12 h-12 border-2 border-purple-200">
                <AvatarImage src="/friendly-ai-avatar.png" />
                <AvatarFallback className="bg-purple-100 text-purple-600">
                  <Bot className="w-6 h-6" />
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                  AI Wellness Companion <Heart className="w-6 h-6 text-purple-500" />
                </h1>
                <p className="text-gray-600">Always here to listen and support you</p>
              </div>
            </div>
          </div>

          {/* Chat Messages */}
          <div className="bg-white/95 backdrop-blur-md h-96 overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`flex items-start space-x-3 max-w-xs lg:max-w-md`}>
                  {message.sender === "ai" && (
                    <Avatar className="w-8 h-8 border border-purple-200">
                      <AvatarFallback className="bg-purple-100 text-purple-600">
                        <Bot className="w-4 h-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}

                  <Card
                    className={`${
                      message.sender === "user" ? "bg-purple-500 text-white" : "bg-gray-100 text-gray-800"
                    } border-0 shadow-sm`}
                  >
                    <CardContent className="p-3">
                      <p className="text-sm leading-relaxed">{message.content}</p>
                      <p className={`text-xs mt-2 ${message.sender === "user" ? "text-purple-100" : "text-gray-500"}`}>
                        {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </CardContent>
                  </Card>

                  {message.sender === "user" && (
                    <Avatar className="w-8 h-8 border border-purple-200">
                      <AvatarFallback className="bg-purple-500 text-white">
                        <User className="w-4 h-4" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex justify-start">
                <div className="flex items-start space-x-3">
                  <Avatar className="w-8 h-8 border border-purple-200">
                    <AvatarFallback className="bg-purple-100 text-purple-600">
                      <Bot className="w-4 h-4" />
                    </AvatarFallback>
                  </Avatar>
                  <Card className="bg-gray-100 border-0 shadow-sm">
                    <CardContent className="p-3">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="bg-white/90 backdrop-blur-md rounded-b-3xl p-6 border-t border-purple-100">
            <div className="flex space-x-4">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Share what's on your mind..."
                className="flex-1 border-purple-200 focus:border-purple-400 focus:ring-purple-400"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!inputValue.trim() || isTyping}
                className="bg-purple-500 hover:bg-purple-600 text-white px-6"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2 text-center">
              Press Enter to send • Your conversations are private and secure
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
