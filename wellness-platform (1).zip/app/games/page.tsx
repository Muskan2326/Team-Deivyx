"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Brain, Heart, Zap, Target } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const games = [
  {
    id: 1,
    title: "Breathing Exercise",
    description: "Guided breathing to reduce anxiety and stress",
    icon: Heart,
    color: "bg-blue-100 text-blue-600",
    duration: "5 min",
  },
  {
    id: 2,
    title: "Mindfulness Meditation",
    description: "Focus on the present moment and calm your mind",
    icon: Brain,
    color: "bg-purple-100 text-purple-600",
    duration: "10 min",
  },
  {
    id: 3,
    title: "Gratitude Practice",
    description: "Reflect on positive aspects of your life",
    icon: Zap,
    color: "bg-yellow-100 text-yellow-600",
    duration: "3 min",
  },
  {
    id: 4,
    title: "Progressive Relaxation",
    description: "Systematic muscle relaxation technique",
    icon: Target,
    color: "bg-green-100 text-green-600",
    duration: "15 min",
  },
]

export default function GamesPage() {
  const [activeGame, setActiveGame] = useState<number | null>(null)

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-lavender-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Wellness Games</h1>
          <p className="text-slate-600">Interactive exercises for mental wellness and relaxation</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {games.map((game, index) => (
            <motion.div
              key={game.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="border-lavender/20 shadow-lg hover:shadow-xl transition-all cursor-pointer">
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${game.color}`}>
                      <game.icon className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-slate-800">{game.title}</h3>
                      <p className="text-sm text-slate-500">{game.duration}</p>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-4">{game.description}</p>
                  <Button onClick={() => setActiveGame(game.id)} className="w-full bg-lavender hover:bg-lavender/90">
                    Start Exercise
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {activeGame && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
            onClick={() => setActiveGame(null)}
          >
            <Card className="w-full max-w-md" onClick={(e) => e.stopPropagation()}>
              <CardHeader>
                <CardTitle>Exercise Starting...</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-600 mb-4">
                  Your wellness exercise is about to begin. Find a comfortable position and follow the guided
                  instructions.
                </p>
                <div className="flex gap-2">
                  <Button onClick={() => setActiveGame(null)} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                  <Button className="flex-1 bg-lavender hover:bg-lavender/90">Begin</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  )
}
