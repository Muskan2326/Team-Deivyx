"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Calendar, Heart, Smile, Frown, Meh } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const moodOptions = [
  { icon: Smile, label: "Great", color: "text-green-500", value: 5 },
  { icon: Heart, label: "Good", color: "text-blue-500", value: 4 },
  { icon: Meh, label: "Okay", color: "text-yellow-500", value: 3 },
  { icon: Frown, label: "Low", color: "text-orange-500", value: 2 },
  { icon: Frown, label: "Very Low", color: "text-red-500", value: 1 },
]

export default function DiaryPage() {
  const [selectedMood, setSelectedMood] = useState<number | null>(null)
  const [entry, setEntry] = useState("")
  const [entries, setEntries] = useState<
    Array<{
      date: string
      mood: number
      content: string
    }>
  >([])

  const handleSave = () => {
    if (selectedMood && entry.trim()) {
      const newEntry = {
        date: new Date().toLocaleDateString(),
        mood: selectedMood,
        content: entry,
      }
      setEntries([newEntry, ...entries])
      setSelectedMood(null)
      setEntry("")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-lavender-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Daily Diary</h1>
          <p className="text-slate-600">Reflect on your day and track your emotions</p>
        </motion.div>

        <Card className="border-lavender/20 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-lavender" />
              Today's Entry
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">How are you feeling today?</label>
              <div className="flex gap-4 justify-center">
                {moodOptions.map((mood) => (
                  <motion.button
                    key={mood.value}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedMood(mood.value)}
                    className={`p-3 rounded-full border-2 transition-all ${
                      selectedMood === mood.value
                        ? "border-lavender bg-lavender/10"
                        : "border-gray-200 hover:border-lavender/50"
                    }`}
                  >
                    <mood.icon className={`h-6 w-6 ${mood.color}`} />
                  </motion.button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Write about your day</label>
              <Textarea
                value={entry}
                onChange={(e) => setEntry(e.target.value)}
                placeholder="What happened today? How did it make you feel?"
                className="min-h-32 border-lavender/20 focus:border-lavender"
              />
            </div>

            <Button
              onClick={handleSave}
              disabled={!selectedMood || !entry.trim()}
              className="w-full bg-lavender hover:bg-lavender/90"
            >
              Save Entry
            </Button>
          </CardContent>
        </Card>

        {entries.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold text-slate-800">Previous Entries</h2>
            {entries.map((entry, index) => {
              const mood = moodOptions.find((m) => m.value === entry.mood)
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="border-lavender/20">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-2">
                        {mood && <mood.icon className={`h-5 w-5 ${mood.color}`} />}
                        <span className="font-medium text-slate-700">{entry.date}</span>
                      </div>
                      <p className="text-slate-600">{entry.content}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
