"use client"

import { motion } from "framer-motion"
import { Play, Clock, User } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

const videos = [
  {
    id: 1,
    title: "Morning Meditation for Anxiety",
    duration: "12:34",
    instructor: "Dr. Sarah Chen",
    thumbnail: "/peaceful-morning-meditation.png",
    category: "Meditation",
  },
  {
    id: 2,
    title: "Breathing Techniques for Stress Relief",
    duration: "8:45",
    instructor: "Mark Johnson",
    thumbnail: "/calming-breathing-exercise-visualization.jpg",
    category: "Breathing",
  },
  {
    id: 3,
    title: "Progressive Muscle Relaxation",
    duration: "15:20",
    instructor: "Dr. Emily Rodriguez",
    thumbnail: "/relaxation-therapy-session.jpg",
    category: "Relaxation",
  },
  {
    id: 4,
    title: "Mindful Walking Practice",
    duration: "10:15",
    instructor: "James Wilson",
    thumbnail: "/mindful-walking-in-nature.jpg",
    category: "Mindfulness",
  },
  {
    id: 5,
    title: "Sleep Meditation for Better Rest",
    duration: "20:30",
    instructor: "Dr. Lisa Park",
    thumbnail: "/peaceful-bedtime-meditation.jpg",
    category: "Sleep",
  },
  {
    id: 6,
    title: "Gratitude Practice Session",
    duration: "7:22",
    instructor: "Michael Brown",
    thumbnail: "/gratitude-journal-and-peaceful-setting.jpg",
    category: "Gratitude",
  },
]

export default function VideosPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-lavender-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Wellness Videos</h1>
          <p className="text-slate-600">Guided sessions for meditation, relaxation, and mindfulness</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="border-lavender/20 shadow-lg hover:shadow-xl transition-all group cursor-pointer">
                <div className="relative overflow-hidden rounded-t-lg">
                  <img
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                    <Button size="lg" className="bg-white/90 hover:bg-white text-slate-800 rounded-full h-16 w-16 p-0">
                      <Play className="h-6 w-6 ml-1" />
                    </Button>
                  </div>
                  <div className="absolute top-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm">
                    {video.duration}
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="mb-2">
                    <span className="inline-block bg-lavender/20 text-lavender px-2 py-1 rounded-full text-xs font-medium">
                      {video.category}
                    </span>
                  </div>
                  <h3 className="font-semibold text-slate-800 mb-2 line-clamp-2">{video.title}</h3>
                  <div className="flex items-center gap-4 text-sm text-slate-500">
                    <div className="flex items-center gap-1">
                      <User className="h-4 w-4" />
                      {video.instructor}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {video.duration}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}
