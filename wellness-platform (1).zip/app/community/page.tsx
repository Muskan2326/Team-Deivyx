import { Navigation } from "@/components/navigation"
import { BackgroundAnimation } from "@/components/background-animation"
import { CommunityFeed } from "@/components/community-feed"
import { CreatePost } from "@/components/create-post"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Heart, MessageCircle } from "lucide-react"

export default function CommunityPage() {
  return (
    <div className="min-h-screen relative">
      <BackgroundAnimation />
      <Navigation />

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 animate-slide-in">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Community Support</h1>
            <p className="text-lg text-muted-foreground text-pretty">
              Connect with others on their wellness journey. Share experiences, offer support, and find encouragement.
            </p>
          </div>

          {/* Community Stats */}
          <div className="grid md:grid-cols-3 gap-4 mb-8">
            <Card className="text-center hover:shadow-lg transition-all duration-200 hover:scale-105">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Users className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-2xl">1,247</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Active Members</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-200 hover:scale-105">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Heart className="w-6 h-6 text-secondary" />
                </div>
                <CardTitle className="text-2xl">8,432</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Support Given</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-200 hover:scale-105">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <MessageCircle className="w-6 h-6 text-accent" />
                </div>
                <CardTitle className="text-2xl">3,156</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Posts Shared</CardDescription>
              </CardContent>
            </Card>
          </div>

          {/* Create Post Section */}
          <div className="mb-8">
            <CreatePost />
          </div>

          {/* Community Feed */}
          <CommunityFeed />
        </div>
      </main>
    </div>
  )
}
