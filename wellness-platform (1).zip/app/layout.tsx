import type React from "react"
import type { Metadata } from "next"
import { Poppins, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import "./globals.css"
import { BackgroundAudio } from "@/components/background-audio"

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-poppins",
})

const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-geist-mono",
})

export const metadata: Metadata = {
  title: "MindHeart - Your Mental Wellness Journey",
  description:
    "A supportive platform for mental health and wellness with AI assistance, community support, and mood tracking.",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`font-sans ${poppins.variable} ${geistMono.variable} antialiased`}>
        <Suspense fallback={null}>
          {children}
          <BackgroundAudio />
          <Analytics />
        </Suspense>
      </body>
    </html>
  )
}
