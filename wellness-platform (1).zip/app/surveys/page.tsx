import { Navigation } from "@/components/navigation"
import { BackgroundAnimation } from "@/components/background-animation"
import { SurveySelector } from "@/components/survey-selector"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ClipboardList, Heart, Brain, Utensils } from "lucide-react"

export default function SurveyPage() {
  return (
    <div className="min-h-screen relative">
      <BackgroundAnimation />
      <Navigation />

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 animate-slide-in">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Wellness Assessments</h1>
            <p className="text-lg text-muted-foreground text-pretty">
              Take validated assessments to better understand your mental health and wellness patterns. Your responses
              help create personalized insights.
            </p>
          </div>

          {/* Survey Overview */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="text-center hover:shadow-lg transition-all duration-200 hover:scale-105">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Brain className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">PHQ-9</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Depression screening questionnaire</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-200 hover:scale-105">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Heart className="w-6 h-6 text-secondary" />
                </div>
                <CardTitle className="text-lg">GAD-7</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Anxiety assessment tool</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-200 hover:scale-105">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <ClipboardList className="w-6 h-6 text-accent" />
                </div>
                <CardTitle className="text-lg">GHQ</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>General health questionnaire</CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-all duration-200 hover:scale-105">
              <CardHeader className="pb-2">
                <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Utensils className="w-6 h-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Food Survey</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>Nutrition and eating habits</CardDescription>
              </CardContent>
            </Card>
          </div>

          {/* Survey Selector */}
          <SurveySelector />
        </div>
      </main>
    </div>
  )
}
