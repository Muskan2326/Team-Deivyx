import { Navigation } from "@/components/navigation"
import { BackgroundAnimation } from "@/components/background-animation"
import { BackgroundSystem } from "@/components/background-system"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import {
  Shield,
  Clock,
  Award,
  MessageCircle,
  Users,
  Video,
  Gamepad2,
  BookOpen,
  Palette,
  Heart,
  Sparkles,
} from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen relative">
      <BackgroundSystem />
      <BackgroundAnimation />

      <Navigation />

      <main className="relative z-10">
        {/* Hero Section */}
        <section className="container mx-auto px-6 py-20 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="bg-black/20 backdrop-blur-sm rounded-3xl p-8 mb-16">
              <div className="flex justify-center items-center space-x-4 mb-8">
                <Heart className="w-16 h-16 text-purple-200 drop-shadow-lg" />
                <Sparkles className="w-12 h-12 text-yellow-200 drop-shadow-lg" />
              </div>

              <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 text-balance drop-shadow-lg">
                Your Mental Wellness
                <br />
                Journey Starts Here
              </h1>

              <p className="text-xl md:text-2xl text-white max-w-3xl mx-auto mb-12 text-pretty leading-relaxed drop-shadow-md">
                MindHeart is your compassionate companion for mental health support.
                <br />
                Connect with AI friends, join caring communities, and access professional
                <br />
                guidance—all in a warm, judgment-free environment.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300 border-0"
                >
                  Start Your Journey →
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-2 border-white text-white hover:bg-white hover:text-purple-600 px-8 py-4 text-lg rounded-full bg-black/20 backdrop-blur-sm transition-all duration-300"
                >
                  Create Free Account
                </Button>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader className="text-center pb-4">
                  <Shield className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-lg font-semibold text-gray-800">Safe & Private</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 font-medium">100% Confidential</CardDescription>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader className="text-center pb-4">
                  <Clock className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-lg font-semibold text-gray-800">24/7 Support</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 font-medium">Always Available</CardDescription>
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader className="text-center pb-4">
                  <Award className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-lg font-semibold text-gray-800">Evidence-Based</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 font-medium">Clinically Proven</CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Everything You Need Section */}
        <section className="py-20 bg-black/10 backdrop-blur-sm">
          <div className="container mx-auto px-6">
            <div className="bg-black/20 backdrop-blur-sm rounded-3xl p-8 mb-16">
              <div className="text-center">
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 drop-shadow-lg">
                  Everything You Need for Mental Wellness
                </h2>
                <p className="text-xl text-white max-w-3xl mx-auto drop-shadow-md">
                  Discover our comprehensive suite of tools and support systems
                  <br />
                  designed to nurture your mental health and emotional wellbeing.
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              <Card className="bg-white/90 backdrop-blur-md border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <CardHeader className="text-center">
                  <MessageCircle className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-xl font-semibold text-gray-800">AI Friend</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 mb-4">
                    Chat with compassionate AI companions trained to support your mental wellness
                  </CardDescription>
                  <Link href="/chatbot">
                    <Button
                      variant="outline"
                      className="w-full text-purple-600 border-purple-300 hover:bg-purple-50 bg-white"
                    >
                      Explore →
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-md border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <CardHeader className="text-center">
                  <Users className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-xl font-semibold text-gray-800">Peer Support</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 mb-4">
                    Connect with others who understand your journey in our supportive community
                  </CardDescription>
                  <Link href="/community">
                    <Button
                      variant="outline"
                      className="w-full text-purple-600 border-purple-300 hover:bg-purple-50 bg-white"
                    >
                      Explore →
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-md border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <CardHeader className="text-center">
                  <Video className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-xl font-semibold text-gray-800">Video Coaching</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 mb-4">
                    Professional counselors and coaches available for video sessions
                  </CardDescription>
                  <Link href="/coaching">
                    <Button
                      variant="outline"
                      className="w-full text-purple-600 border-purple-300 hover:bg-purple-50 bg-white"
                    >
                      Explore →
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-md border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <CardHeader className="text-center">
                  <Gamepad2 className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-xl font-semibold text-gray-800">Wellness Games</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 mb-4">
                    Fun, therapeutic games designed to boost mood and reduce stress
                  </CardDescription>
                  <Link href="/games">
                    <Button
                      variant="outline"
                      className="w-full text-purple-600 border-purple-300 hover:bg-purple-50 bg-white"
                    >
                      Explore →
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-md border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <CardHeader className="text-center">
                  <BookOpen className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-xl font-semibold text-gray-800">Personal Diary</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 mb-4">
                    Private journaling space to track thoughts, moods, and progress
                  </CardDescription>
                  <Link href="/diary">
                    <Button
                      variant="outline"
                      className="w-full text-purple-600 border-purple-300 hover:bg-purple-50 bg-white"
                    >
                      Explore →
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-md border-white/30 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <CardHeader className="text-center">
                  <Palette className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <CardTitle className="text-xl font-semibold text-gray-800">Express Yourself</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-gray-700 mb-4">
                    Creative tools for art, music, and self-expression therapy
                  </CardDescription>
                  <Link href="/express">
                    <Button
                      variant="outline"
                      className="w-full text-purple-600 border-purple-300 hover:bg-purple-50 bg-white"
                    >
                      Explore →
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
