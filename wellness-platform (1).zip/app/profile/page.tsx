import { Navigation } from "@/components/navigation"
import { BackgroundAnimation } from "@/components/background-animation"
import { AvatarCreator } from "@/components/avatar-creator"
import { ProfileForm } from "@/components/profile-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, Palette } from "lucide-react"

export default function ProfilePage() {
  return (
    <div className="min-h-screen relative">
      <BackgroundAnimation />
      <Navigation />

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 animate-slide-in">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Your Profile</h1>
            <p className="text-lg text-muted-foreground text-pretty">
              Customize your avatar and manage your account settings
            </p>
          </div>

          <Tabs defaultValue="avatar" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="avatar" className="flex items-center space-x-2">
                <Palette className="w-4 h-4" />
                <span>Create Your Avatar</span>
              </TabsTrigger>
              <TabsTrigger value="account" className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>Your Account</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="avatar" className="animate-slide-in">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Palette className="w-5 h-5 text-primary" />
                    <span>Avatar Creator</span>
                  </CardTitle>
                  <CardDescription>Design your unique 3D avatar that represents you in the community</CardDescription>
                </CardHeader>
                <CardContent>
                  <AvatarCreator />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="account" className="animate-slide-in">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <User className="w-5 h-5 text-primary" />
                    <span>Account Information</span>
                  </CardTitle>
                  <CardDescription>Manage your personal information and account settings</CardDescription>
                </CardHeader>
                <CardContent>
                  <ProfileForm />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
