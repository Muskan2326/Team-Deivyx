import { Navigation } from "@/components/navigation"
import { BackgroundAnimation } from "@/components/background-animation"
import { VolunteerChat } from "@/components/volunteer-chat"
import { HelplinNumbers } from "@/components/helpline-numbers"
import { FAQSection } from "@/components/faq-section"
import { ContactForm } from "@/components/contact-form"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MessageCircle, Phone, HelpCircle, Mail } from "lucide-react"

export default function HelpPage() {
  return (
    <div className="min-h-screen relative">
      <BackgroundAnimation />
      <Navigation />

      <main className="relative z-10 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 animate-slide-in">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Get Support</h1>
            <p className="text-lg text-muted-foreground text-pretty">
              We're here to help. Connect with volunteers, access crisis resources, or find answers to common questions.
            </p>
          </div>

          <Tabs defaultValue="volunteers" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="volunteers" className="flex items-center space-x-2">
                <MessageCircle className="w-4 h-4" />
                <span className="hidden sm:inline">Volunteers</span>
              </TabsTrigger>
              <TabsTrigger value="helplines" className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span className="hidden sm:inline">Helplines</span>
              </TabsTrigger>
              <TabsTrigger value="faq" className="flex items-center space-x-2">
                <HelpCircle className="w-4 h-4" />
                <span className="hidden sm:inline">FAQ</span>
              </TabsTrigger>
              <TabsTrigger value="contact" className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span className="hidden sm:inline">Contact</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="volunteers" className="animate-slide-in">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MessageCircle className="w-5 h-5 text-primary" />
                    <span>Chat with Volunteers</span>
                  </CardTitle>
                  <CardDescription>
                    Connect with trained peer support volunteers who understand your journey
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <VolunteerChat />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="helplines" className="animate-slide-in">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Phone className="w-5 h-5 text-primary" />
                    <span>Crisis Helplines</span>
                  </CardTitle>
                  <CardDescription>24/7 professional support when you need immediate help</CardDescription>
                </CardHeader>
                <CardContent>
                  <HelplinNumbers />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="faq" className="animate-slide-in">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <HelpCircle className="w-5 h-5 text-primary" />
                    <span>Frequently Asked Questions</span>
                  </CardTitle>
                  <CardDescription>Find answers to common questions about mental health and wellness</CardDescription>
                </CardHeader>
                <CardContent>
                  <FAQSection />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="contact" className="animate-slide-in">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Mail className="w-5 h-5 text-primary" />
                    <span>Send us a Message</span>
                  </CardTitle>
                  <CardDescription>Reach out to our team using your User ID for personalized support</CardDescription>
                </CardHeader>
                <CardContent>
                  <ContactForm />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
